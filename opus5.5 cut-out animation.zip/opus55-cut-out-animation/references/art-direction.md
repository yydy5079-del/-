# 正式作品美术导演简报

开始制作前写ART_DIRECTION.md，回答：本题的主角资产属于什么时代/行业、人物/机器应有何真实细节、需要哪些部件运动、哪些对象承担证据、色彩与版式如何一致。选一个代表场景先渲染style frame；不能拿技术fixture充当美术样张。

## 三层语言

1. 素材层：雕版线刻、处理过的真实照片或细密半色调插画，主体有完整轮廓。近景能辨认结构，远景有清楚剪影。优先单色/双色处理，不默认现代商业扁平矢量人物。
2. 纸面层：薄纸托边、撕边纸片、牛皮纸、墨色印记、低而软的接触阴影。材料不同，但颗粒、光向和边缘质量统一。
3. 编辑层：代码生成的主标题、标签、短说明、数据和关系。大标题、次级标签和辅助说明有明显级差，避免几十个同号纸条。

暖纸底可从#E9E3D5、墨色#24221E、印泥红#A93127起步。牛皮纸仅在语义需要时局部使用。照片色温与纸底协调，不把所有资产套同一种重褐色滤镜。现代题材也可保留灰度剪贴+单一强调色，而不强行使用古装与旧机器。

## 主角与文字比例

通常一组主角与关系占画面主要区域。主体常占宽度40%—65%，双对象对照共同占主区域。标题可以较大，但不能掩盖操作部件。细节镜头负责看清接口、动作或证据，不能全片始终是同样的大全景。

中文主标题Noto Sans SC，辅助Alibaba PuHuiTi Regular；不把英文参考片的逐字拼贴、哥特字形或手写体强套中文。可按词组用不同纸条衬底，字形本身不扭曲、不随机跳动。英文装饰刊头另选有许可且实际加载的字体时记录来源，不能假称系统替代字体就是目标字形。

## 静态图像生成提示模板

“One isolated [主体与准确年代/工艺], [完整轮廓和部件可见关系], archival engraving / detailed halftone photographic cut-out, precise material and mechanism details, unified soft light from upper left, restrained monochrome ink on warm paper, clean separable silhouette, [后续分层需要的无遮挡姿态], no text, no letters, no numbers, no labels, no logos, no watermark. Do not generate a finished poster or video frame.”

一个主体一套资产，不让生成器把人物、机器、标题和完整背景画死在一张图里。要指向就准备可分离上臂/前臂；要进纸就准备纸带与滚筒；要翻页就分封面、纸页、铰接边。若无法分层，应实际再生成合适部件，而不是把整图摇动冒充操作。

Higgsfield只负责静态无字图像；不可用时如实选择现有图像工具、授权资产或原创高细节线刻矢量。几何玩具机器和无脸色块人物只能用于工程测试，不能默认为正式作品。

需要准确地图时使用有许可地理数据生成轮廓，不把图像模型生成的地图当作精确地理事实。需要史料时记录来源；图像生成不承担事实证明。

## 资产登记

assets.json顶层visual_family="editorial-photo-engraving-collage"。assets每项至少id、source、no_embedded_text:true、style、role、parts；image项还记录实际尺寸与最大展示尺寸。no_embedded_text是需要人工/工具复核的声明，不是自动OCR结论。生成素材不得带文字；史料需要文字时另有来源说明，不通过生成器伪造，并把它与解释性代码文字分开。
