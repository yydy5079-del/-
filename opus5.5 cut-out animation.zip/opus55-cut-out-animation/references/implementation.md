# 可执行接口与复现

## 目录与准备

`PROJECT_DIR`包含源码：project.json、narration.txt、alignment.json、STORYBOARD.md、scene.json、events.json、art.mjs、assets.json、build.sh。

`OUTPUT_DIR`在仓库外，包含objects/、frames/、review/、声音分轨、film.mp4和报告；`CACHE_DIR`存字体、私有依赖和语音模型。

初始化默认mode="production"。正式构建前还需ART_DIRECTION.md与assets.json。技术示例脚本显式使用mode="technical-fixture"，不会将缺少口播锚点的功能测试伪装成正式成片。

```bash
python3 "$SKILL_DIR/scripts/setup.py" --cache "$CACHE_DIR"
python3 "$SKILL_DIR/scripts/init_project.py" --project "$PROJECT_DIR" \
  --audio "$VOICE_FILE" --text "$TEXT_FILE" --out "$OUTPUT_DIR" \
  --source-repo "$REPOSITORY_ROOT"
```

setup可用 `--python` 和 `--playwright-module` 复用已安装私有工具。实际路径记录在cache/runtime.json。缺少FFmpeg/Chromium时返回明确缺项，执行agent使用获准包源安装，不要求用户手动处理本可完成的依赖。

可选ASR接口：安装sherpa-onnx到私有环境，按官方 https://github.com/k2-fsa/sherpa-onnx/releases/tag/asr-models 的文件信息准备SenseVoice模型并校验。然后调用 `scripts/transcribe.py --audio ... --model-dir ... --out ...`。若模型不输出token时间戳，改用真实对齐工具或听检锚点，不按字数均分。

## scene.json

```json
{
  "duration": 4.8,
  "seed": 55,
  "background": {"color":"#ECE7DC"},
  "assets": {"figure":"figure-body.png"},
  "subs": [],
  "loop": {"enabled":false},
  "camera": [
    {"t":0,"x":960,"y":540,"zoom":1,"roll":0},
    {"t":2,"x":960,"y":540,"zoom":1,"roll":0},
    {"t":3,"x":1040,"y":460,"zoom":1.1,"roll":0}
  ],
  "actors": [
    {"id":"figure","type":"custom","drawer":"person","important":true,
      "x":600,"y":550,"w":340,"h":450,"depth":5}
  ]
}
```

duration必须等于frames/30。camera为绝对世界坐标，不是相对增量；zoom为倍率，roll为度。保持同一坐标的相邻关键帧即停稳。模板默认无运动模糊，避免低采样重影。

1.1新增弧线：在终点关键帧添加control1:[cx1,cy1]、control2:[cx2,cy2]，二者为绝对世界坐标。位置按三次Bezier曲线、时间按quintic smootherstep采样，zoom仍对数插值。端点速度与加速度连续到0，便于从观察段进入阅读段；需要不断速连续轨迹时另写C2样条，不连成多次急停。

actor类型：paper、text、image、path、custom。绘制原点为对象中心，文字基线middle；path的points是对象局部坐标。image使用assets中的id与w/h，不随包捆绑图像。

image默认合成细纸边，参数matte:{width:3,color:"#F8F2E4"}，width为世界像素；matte:false关闭。原图须有干净alpha；纸边不会自动抠掉背景。渲染器缓存纸边结果，不在每帧重复生成。assetAudit测实际源尺寸与最大zoom下的显示尺寸，拒绝放大低分辨率图或非等比拉伸；建议素材达到最大显示尺寸1.5倍。源文件SHA写入报告。

text必须给text、size、font、weight、reading[start,end]。font为aux时实际字体是Alibaba PuHuiTi、400，其他是Noto Sans SC。正文不能附带随机旋转。主标题可important:true，用underline通道作为关系性二次动作；独立辅助标签标为label或important:false，随所属叙事组稳定阅读。

custom在项目art.mjs中实现：`export const drawers={name(ctx, actor, state, assets, t){...}}`。实际部件使用state.channels驱动，如point、feed、open、execute、feedback。state.entranceProgress可驱动自定义撕纸遮罩或铰接展开；默认入口只实现整体透明度、位移、有限旋转与缩放，不能假称已经实现任意撕纸效果。示例只演示手臂枢轴与进纸遮挡；新主题必须写自己的对象。仅在JSON声明通道而绘图忽略它不算实现。

## 唯一事件表 events.json

```json
{"events":[
  {"id":"arrive","actor":"figure","phase":"entrance","t":0.12,"d":0.6,
   "from":{"x":-180,"y":30,"scale":0.97},"contact":0.48,
   "meaning":"人物剪贴滑入并落稳",
   "sounds":[
     {"id":"slide","stage":"onset","kind":"paper_slide","offset":0,"duration":0.45},
     {"id":"touch","stage":"contact","kind":"paper_tap","offset":0.48,"duration":0.12}
   ]},
  {"id":"point","actor":"figure","phase":"secondary","t":1.0,"d":0.7,
   "channel":"point","fromValue":0,"toValue":1,"contact":0.5,
   "meaning":"到位后指向解释对象",
   "sounds":[{"id":"point-stop","stage":"contact","kind":"paper_fold","offset":0.5,"duration":0.16}]}
]}
```

t为绝对秒，d为持续秒，contact/sound.offset为相对本事件起点。所有id唯一。

phase支持entrance、secondary、accent、exit。entrance从from变换到对象基础姿态；默认scale=1，不让全部元素从0放大。secondary从fromValue到toValue，mode:return可返回，但不能只用呼吸缩放充当语义动作。dx/dy/rotation/scale为通用变换，其余交给具体drawer。path的trace通道控制真实路径进度；text的underline控制字下关系线。

1.1新增真实入口遮罩：在entrance事件添加reveal:{kind:"tear",from:"left",edge:12}或{kind:"wipe",from:"top"}。from支持left/right/top/bottom。tear边缘由固定seed生成，不逐帧抖动；它是沿轮廓裁切揭示，不是物理撕下碎屑。开启reveal后主体不再同时整体淡入，避免“看似擦除其实只是透明度”。自定义actor需给w/h，text按真实字宽计算遮罩。遮罩只负责入场，入场后仍要有secondary。

有因果时添加depends_on:[event-id]，事件不能早于前因contact；没有contact则等待前因结束。有真实关键词复核时添加anchor:{text,time,hit:"contact"或"start",confirmed:true}；没复核不能填true。技术用例没有语义对齐证据会明确警告。

正式项目的important secondary必须另填keyword_id，关联alignment.json内真实关键词；未复核是错误，不是可忽略警告。alignment.json需audio_sha256、decoded_duration、phrases:[{text,start,end,keywords:[{id,text,time,method}]}]。method可为forced-align/asr-reviewed/manual-reviewed，必须如实记录。anchor.time与keyword.time相差不超过1帧，动作与anchor在0.10秒目标内。确认时间不能替代语义审看。

assets.json顶层包含visual_family:"editorial-photo-engraving-collage"、assets:[{id,source,no_embedded_text:true,style,parts,...}]。正式项目要求实际美术导演简报与来源清单，不把无字标记误称为自动OCR通过。高细节原创矢量可登记source为实际代码文件；不能把技术玩具图形冒充雕版/照片资产。

内置基础Foley：paper_slide、paper_fold、paper_tap、tear、magnet、ink、clasp、relay、motor、feedback、air。用真实素材时sound给src（相对外部objects/）、src_offset、duration、source，代替kind。level_db是相对本地口播参考的初始权重，默认−8；最终按叠加总线校准。pan范围−1..1。

## 预览、构建、复核

```bash
python3 "$SKILL_DIR/scripts/validate.py" --project "$PROJECT_DIR"
node "$SKILL_DIR/scripts/render.mjs" --project "$PROJECT_DIR" \
  --runtime "$CACHE_DIR/runtime.json" --stills 0,0.5,1.5,2.5
SKILL_DIR="$SKILL_DIR" RUNTIME_JSON="$CACHE_DIR/runtime.json" \
  PROJECT_DIR="$PROJECT_DIR" bash "$PROJECT_DIR/build.sh"
```

渲染支持2—4workers，仅监听127.0.0.1，结束后关闭服务与浏览器。帧由frame/30派生，输出6位编号JPEG。完整渲染前只清理本项目frames/中的6位生成帧，防止旧长片混入，不碰其他文件。

render-report包含首帧与纯背景的像素相等检查、实际actor状态、camera和源码哈希。loop开启时检查最后一个实际采样帧与首帧及相机起止状态；verify_video还读取实际H.264首末帧，要求平均RGB误差≤2/255。音频边界仍需额外听检。

secondaryAudit在隔离对象、固定相机下比较动作前后像素，拦住声明了通道却没有绘制实现的情况；不能证明一个随机移动符合口播。assetAudit与assetHashes分别记录素材尺寸、比例和实际文件摘要。

输出voice-stem.wav保留原声声道，sfx-stem.wav、mix-premaster.wav、mix.wav、sound-report.json、quality-report.json。sound-report逐cue记录实际时间、来源和局部总线比值；母带只对合成整体处理。

自动检查不证明审美与语义。必须实际查看重要部件的二次动作，必要时输出姿态差分；检查人像指向、阀杆接触、纸张遮挡和信息因果，再听对应段落。
