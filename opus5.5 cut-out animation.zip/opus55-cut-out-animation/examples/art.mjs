// Original procedural paper figures for technical QA, not a finished story.
function polygon(c,points,fill){c.beginPath();c.moveTo(...points[0]);for(const p of points.slice(1))c.lineTo(...p);c.closePath();c.fillStyle=fill;c.fill();}
function disc(c,x,y,r,color){c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fillStyle=color;c.fill();}
function rectangle(c,x,y,w,h,color){c.fillStyle=color;c.fillRect(x,y,w,h);}
function halftone(c,x,y,w,h,color){c.save();c.beginPath();c.rect(x,y,w,h);c.clip();for(let i=0;i<w;i+=13)for(let j=0;j<h;j+=13)disc(c,x+i,y+j,1.5,color);c.restore();}
export const drawers={
 person(c,a,s){
  c.save();c.scale(a.w/360,a.h/480);
  // A light paper border carries the cut-out silhouette.
  polygon(c,[[-103,211],[-115,38],[-71,-20],[-60,-73],[-76,-117],[-64,-183],[-10,-210],[51,-184],[65,-126],[53,-74],[67,-24],[112,31],[96,213]],'#F9F4E5');
  polygon(c,[[-89,199],[-101,44],[-57,-7],[0,15],[58,-6],[98,44],[80,199]],'#204E53');
  halftone(c,-90,38,170,160,'rgba(4,25,27,.3)');
  polygon(c,[[-29,-28],[-27,-65],[34,-67],[30,-27],[1,3]],'#B68D69');
  polygon(c,[[-53,-161],[-16,-193],[41,-172],[47,-109],[24,-73],[-28,-76],[-51,-112]],'#C4A080');
  polygon(c,[[-58,-145],[-56,-176],[-11,-202],[41,-181],[50,-148],[15,-160],[-18,-150]],'#302D27');
  polygon(c,[[-43,-12],[-5,16],[-24,40],[-57,7]],'#F9F5E9');
  polygon(c,[[43,-12],[-5,16],[17,41],[61,6]],'#F9F5E9');
  rectangle(c,-8,18,9,82,'#A9382D');
  // Pivot at shoulder: the arm points after arrival.
  c.save();c.translate(63,27);c.rotate(-.12-(s.channels.point||0)*.78);
  polygon(c,[[-17,-17],[30,-10],[111,100],[87,122],[4,55]],'#F9F4E5');
  polygon(c,[[-11,-11],[24,-5],[99,94],[83,106],[7,49]],'#285D60');
  polygon(c,[[83,106],[98,93],[123,108],[147,111],[149,122],[120,127],[102,124]],'#C4A080');c.restore();
  c.shadowColor='transparent';c.strokeStyle='#65503E';c.lineWidth=2;c.beginPath();c.moveTo(27,-126);c.lineTo(35,-117);c.lineTo(28,-113);c.stroke();
  c.restore();
 },
 machine(c,a,s){
  c.save();c.scale(a.w/500,a.h/380);const feed=s.channels.feed||0;
  polygon(c,[[-240,159],[-240,-91],[-184,-146],[172,-146],[239,-86],[239,158]],'#FCF8ED');
  rectangle(c,-224,-80,447,222,'#314C51');halftone(c,-224,-80,447,222,'rgba(8,24,25,.35)');
  polygon(c,[[-224,-80],[-174,-131],[165,-131],[223,-80]],'#6A8181');
  // The paper is clipped by a physical feed slot, not moved over the front panel.
  c.save();c.beginPath();c.rect(-154,-231,308,174);c.clip();
  c.translate(0,feed*125);polygon(c,[[-130,-234],[127,-234],[132,-79],[-130,-79]],'#F1E5C7');
  for(let y=-213;y<-105;y+=16)rectangle(c,-104,y,170-(y%3)*12,3,'#B3A68A');c.restore();
  rectangle(c,-158,-83,316,17,'#182E34');
  rectangle(c,-185,-34,273,123,'#E0D6BD');
  rectangle(c,-166,-12,232,9,'#304E53');
  for(let x=-164;x<59;x+=28)rectangle(c,x,19,11,47,'#B4A78A');
  c.save();c.translate(154,20);c.rotate(feed*Math.PI*2);disc(c,0,0,43,'#C2B99D');disc(c,0,0,25,'#42595A');
  for(let i=0;i<6;i++){c.rotate(Math.PI/3);rectangle(c,21,-5,24,10,'#C2B99D');}disc(c,0,0,7,'#AD3B2C');c.restore();
  rectangle(c,-235,130,470,27,'#B7402D');rectangle(c,-210,157,56,25,'#393D36');rectangle(c,153,157,56,25,'#393D36');
  c.restore();
 }
};
