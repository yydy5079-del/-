# 技术演示，不是固定视频模板

准备至少4.8秒的合法测试口播与对应文本，初始化仓库外项目，再运行make_fixture.py。

```bash
python3 "$SKILL_DIR/scripts/init_project.py" --project /external/cutout-fixture \
  --audio /external/test-voice.wav --text /external/test-text.txt --out /external/fixture-output
python3 "$SKILL_DIR/scripts/make_fixture.py" --project /external/cutout-fixture
SKILL_DIR="$SKILL_DIR" RUNTIME_JSON="$CACHE_DIR/runtime.json" \
  PROJECT_DIR=/external/cutout-fixture bash /external/cutout-fixture/build.sh
```

验证第0帧只有纸底，人物与机器先入场再有手臂/进纸动作，标题下划线、关系路径、辅助字、双方向摄影机和逐接触声音。图形是原创程序绘制，用于工程验证；不可将其重复交给用户当作新题材的精美科普视频。

新视频必须由agent根据文案创建自己的art.mjs、无字资产、场景和事件表。源文件中写出“point”并不能证明人物指向正确，最终仍需实际看图、看片。

## 1.1素材与遮罩检查

在另一个至少4.8秒的已初始化项目中，运行 `python3 "$SKILL_DIR/scripts/make_editorial_fixture.py" --project "$PROJECT_DIR"`，再按相同build.sh构建。它在外部objects/生成原创无字线刻SVG，测试图片细纸边、固定种子撕纸遮罩、平直文字揭示、真实图片尺寸检查与Bezier相机。不是Higgsfield生成的正式美术，不是印刷机史实复原。
