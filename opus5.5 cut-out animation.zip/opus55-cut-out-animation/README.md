# opus5.5 cut-out animation

将文案与原声MP3制作成报刊剪报混合媒体代码动画的标准Agent Skill。调用标识：`opus55-cut-out-animation`。

输入示例：

> 使用 $opus55-cut-out-animation。文案：…… 附件是我的口播MP3，按默认规格从分镜到成片直接完成。

默认1080p30/H.264、无逐句字幕、原声同步、主要音效低约8dB。第0帧只有纸底，重要人物/对象/标题/数字先入场，再发生解释语义的二次动作。多方向局部运镜、Noto Sans SC主字、Alibaba PuHuiTi Regular辅助字。

## 内容

- `SKILL.md`：工作流与不可省略的制作要求。
- `references/`：分镜、美术分层、动作、摄影机、声音、接口和验收细则。
- `templates/engine.mjs`：确定性剪贴画合成与摄像机引擎。
- `scripts/`：环境与字体准备、初始化、事件验证、渲染、共享事件混音、编码和检查。
- `examples/`：可重现的技术演示；不是固定科普题材。

## 安装

`python3 scripts/install.py --repo /absolute/repository` 安装到仓库的 `.agents/skills/opus55-cut-out-animation`，拒绝盲目覆盖不同版本。新会话由宿主发现。其他Agent宿主请按其本地Skill导入方式安装，不承诺不同产品的导入界面一致。

ZIP仅含代码、文档和字体清单，不包含原声、图像、视频、字体二进制、凭据、模型或依赖。设置工具下载并校验固定字体到仓库外。新任务仍需Agent根据文案设计资产与动作，不能只把文本填进演示。

参考案例的60秒、印刷史、Higgsfield和循环要求属于该案例；本技能默认跟随新原声时长，按当前可用工具制作无字静态资产，循环由当次要求启用。
