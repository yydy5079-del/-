import argparse, hashlib, json
from pathlib import Path
from fontTools.ttLib import TTFont

p=argparse.ArgumentParser();p.add_argument('--fonts',type=Path,required=True);p.add_argument('--text',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parents[1]
sample='剪贴画科普项目数量运行记录控制效果0123456789AI？'
if a.text: sample+=a.text.read_text()
reports=[]
for f in json.loads((root/'fonts.json').read_text())['fonts']:
    path=a.fonts/f['file'];assert path.is_file(),path
    assert hashlib.sha256(path.read_bytes()).hexdigest()==f['sha256'],f['file']+' checksum'
    font=TTFont(path);names={n.toUnicode() for n in font['name'].names if n.nameID in [1,2,16,17]}
    assert any(f['family'] in s for s in names),names
    if 'Alibaba' in f['family']: assert 'Regular' in names,names
    else:
        axes={x.axisTag:(x.minValue,x.maxValue) for x in font['fvar'].axes}
        assert axes['wght'][0]<=700 and axes['wght'][1]>=900,axes
    cmap=font.getBestCmap();missing=sorted({ch for ch in sample if not ch.isspace() and ord(ch) not in cmap})
    assert not missing, f['file']+' missing glyphs: '+''.join(missing)
    reports.append({'file':f['file'],'names':sorted(names),'sample_glyphs':'passed'})
print(json.dumps(reports,ensure_ascii=False,indent=2))
