"""Install in a standard repository skill directory; refuse conflicting versions."""
import argparse,filecmp,json,shutil
from pathlib import Path
source=Path(__file__).resolve().parents[1];slug='opus55-cut-out-animation'
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);a=p.parse_args();dest=a.repo.resolve()/'.agents/skills'/slug
def files(root):return {p.relative_to(root) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
if dest.exists() and dest!=source:
    one,two=files(source),files(dest)
    if one!=two or any(not filecmp.cmp(source/p,dest/p,shallow=False) for p in one):raise SystemExit('Different installed version exists: '+str(dest))
elif dest!=source:
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(source,dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.DS_Store'))
assert (dest/'SKILL.md').is_file() and (dest/'agents/openai.yaml').is_file()
print(json.dumps({'status':'installed','scope':'repository','path':str(dest),'activation':'new conversation or host skill reload'},ensure_ascii=False))
