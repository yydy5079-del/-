"""Read the SAME events as the renderer; preserve voice channels and audit cues."""
import argparse, hashlib, json, subprocess, wave
from pathlib import Path
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.ndimage import uniform_filter1d

p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a=p.parse_args()
cfg=json.loads((a.project/'project.json').read_text());events=json.loads((a.project/'events.json').read_text())['events'];out=Path(cfg['output']);out.mkdir(parents=True,exist_ok=True)
sr=48000;n=round(cfg['frames']/30*sr)
def decode(file,start=None,duration=None):
    cmd=['ffmpeg','-v','error']
    if start is not None:cmd+=['-ss',str(start)]
    cmd+=['-i',str(file)]
    if duration is not None:cmd+=['-t',str(duration)]
    return np.frombuffer(subprocess.check_output(cmd+['-f','f32le','-ar',str(sr),'-ac','2','-']),np.float32).reshape(-1,2).astype(float)
voice=decode(cfg['audio']);assert len(voice)<=n+2,'Would truncate original voice'
voice=np.pad(voice,((0,max(0,n-len(voice))),(0,0)))[:n];fx=np.zeros((n,2));cues=[]
def rms(x):return float(np.sqrt(np.mean(x*x)+1e-15))
def foley(kind,length,seed):
    r=np.random.default_rng(seed);t=np.arange(length)/sr;d=length/sr
    band=sosfilt(butter(3,[300,2600],btype='bandpass',fs=sr,output='sos'),r.standard_normal(length))
    if kind in ['paper_slide','paper_fold','tear','ink','air']:
        env=np.sin(np.pi*np.minimum(t/d,1))**.65
        if kind=='paper_fold':env*=.4+.6*np.sin(2*np.pi*11*t)**2
        if kind=='tear':env*=.4+.6*np.sin(2*np.pi*43*t)**2
        if kind=='ink':band=sosfilt(butter(2,[900,3500],btype='bandpass',fs=sr,output='sos'),band)
        if kind=='air':band*=.25
        return band*env
    if kind in ['paper_tap','magnet','clasp','relay']:
        freq={'paper_tap':140,'magnet':610,'clasp':850,'relay':1300}[kind]
        attack=np.minimum(1,t/.0015);decay={'paper_tap':.038,'magnet':.024,'clasp':.018,'relay':.012}[kind]
        return (band*.48+np.sin(2*np.pi*freq*t)*.34+np.sin(2*np.pi*freq*1.73*t)*.12)*attack*np.exp(-t/decay)
    if kind=='motor':return (.4*np.sin(2*np.pi*105*t)+.16*np.sin(2*np.pi*210*t)+band*.14)*np.sin(np.pi*t/d)**.5
    if kind=='feedback':return (.6*np.sin(2*np.pi*(650*t-100*t*t))+.2*band)*np.sin(np.pi*t/d)**2
    raise ValueError('Unknown Foley kind: '+kind)

global_ref=rms(voice[np.mean(voice**2,axis=1)>.0001]) if np.any(np.mean(voice**2,axis=1)>.0001) else 0
for e in events:
    for cue in e.get('sounds',[]):
        start=e['t']+cue.get('offset',0);i=round(start*sr);k=round(cue['duration']*sr);j=i+k
        assert 0<=i<j<=n,'Cue exceeds actual movie: '+cue['id']
        if cue.get('src'):
            f=(Path(cfg['assets'])/cue['src']).resolve();assert f.is_relative_to(Path(cfg['assets']).resolve()),'Sound path escapes asset folder'
            x=decode(f,cue.get('src_offset',0),cue['duration']);x=np.pad(x,((0,max(0,k-len(x))),(0,0)))[:k]
        else:
            seed=int(hashlib.sha256(cue['id'].encode()).hexdigest()[:8],16)
            mono=foley(cue['kind'],k,seed);x=np.repeat(mono[:,None],2,axis=1)
        ramp=min(round(.003*sr),k//3);tail=min(round(.010*sr),k//3)
        if ramp:x[:ramp]*=np.linspace(0,1,ramp)[:,None]
        if tail:x[-tail:]*=np.linspace(1,0,tail)[:,None]
        reference=voice[max(0,i-7200):min(n,j+7200)];ref=max(rms(reference),global_ref*.45)
        x*=ref/max(rms(x),1e-9)*10**(cue.get('level_db',-8)/20)
        pan=np.clip(cue.get('pan',0),-1,1);x*=np.array([np.cos((pan+1)*np.pi/4),np.sin((pan+1)*np.pi/4)])*np.sqrt(2)
        fx[i:j]+=x;cues.append({'id':cue['id'],'event':e['id'],'stage':cue.get('stage'),'time':start,'duration':cue['duration'],'kind':cue.get('kind','file'),'source':cue.get('source','deterministic procedural Foley')})

ve=np.sqrt(uniform_filter1d(np.mean(voice**2,axis=1),size=7200)+1e-12);fe=np.sqrt(uniform_filter1d(np.mean(fx**2,axis=1),size=7200)+1e-12)
active=(ve>.008)&(fe>.0008);ratio=None
if cues:
    if np.count_nonzero(active)<480:raise SystemExit('No adequate simultaneous voice/effect windows; revise cue timing before claiming −8dB')
    fx*=rms(voice[active])/max(rms(fx[active]),1e-9)/10**(.4);ratio=20*np.log10(rms(voice[active])/rms(fx[active]))
for cue in cues:
    i=round(cue['time']*sr);j=min(n,i+max(round(cue['duration']*sr),7200));mask=active[i:j]
    cue['sfx_bus_below_voice_db']=float(20*np.log10(rms(voice[i:j][mask])/rms(fx[i:j][mask]))) if np.count_nonzero(mask)>100 else None
mix=voice+fx;gain=min(1,.85/max(np.max(np.abs(mix)),1e-9))
def save(name,data):
    with wave.open(str(out/name),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((np.clip(data*gain,-1,1)*32767).astype('<i2').tobytes())
save('voice-stem.wav',voice);save('sfx-stem.wav',fx);save('mix-premaster.wav',mix)
report={'events':len(cues),'sample_rate':sr,'duration':n/sr,'sfx_below_voice_db':ratio,'measurement':'Same 150ms active voice/effect windows; summed SFX bus before common mastering','voice_channels_preserved':True,'common_gain':gain,'cues':cues}
(out/'sound-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='cues'},indent=2))
