import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const argv=process.argv.slice(2),arg=(name,fallback)=>{const i=argv.indexOf(name);return i<0?fallback:argv[i+1];};
const project=path.resolve(arg('--project','.')),runtime=JSON.parse(fs.readFileSync(arg('--runtime')));
const cfg=JSON.parse(fs.readFileSync(path.join(project,'project.json')));
const scene=JSON.parse(fs.readFileSync(path.join(project,'scene.json'))),events=JSON.parse(fs.readFileSync(path.join(project,'events.json'))).events;
const output=path.resolve(cfg.output),repo=path.resolve(cfg.source_repo||project);
if(output===repo||output.startsWith(repo+path.sep))throw Error('Media output must be outside source repository');
if(Math.abs(scene.duration-cfg.frames/30)>1e-7)throw Error('Scene duration differs from measured frame count');
const html=`<!doctype html><meta charset="utf-8"><style>@font-face{font-family:'Noto Sans SC';src:url('/fonts/NotoSansSC.ttf');font-weight:100 900}@font-face{font-family:'Alibaba PuHuiTi';src:url('/fonts/AlibabaPuHuiTi-Regular.ttf');font-weight:400}body{margin:0;font-synthesis:none}canvas{display:block}</style><canvas id="c" width="1920" height="1080"></canvas><script type="module">
import{createEngine,cameraAt}from'/engine.mjs';import{drawers}from'/art.mjs';
try{const [scene,eventFile]=await Promise.all([fetch('/scene.json').then(r=>r.json()),fetch('/events.json').then(r=>r.json())]);
await Promise.all([document.fonts.load('700 48px "Noto Sans SC"'),document.fonts.load('900 48px "Noto Sans SC"'),document.fonts.load('400 48px "Alibaba PuHuiTi"')]);
const faces=[...document.fonts];if(faces.length!==2||faces.some(f=>f.status!=='loaded'))throw Error('Real fonts not loaded');
const assets={};for(const [id,file]of Object.entries(scene.assets||{})){const image=new Image();image.src='/asset/'+encodeURIComponent(file);await image.decode();assets[id]=image;}
window.assetInfo=Object.entries(assets).map(([id,image])=>({id,width:image.naturalWidth,height:image.naturalHeight}));
const engine=createEngine(scene,eventFile.events,assets,drawers);window.draw=(t,backgroundOnly=false)=>{engine.draw(document.getElementById('c'),t,{backgroundOnly});return engine.review(t)};
window.auditSecondaries=()=>{const canvas=document.createElement('canvas');canvas.width=1920;canvas.height=1080;const checks=[];
for(const e of eventFile.events.filter(e=>e.phase==='secondary')){const actor=scene.actors.find(a=>a.id===e.actor);if(!actor?.important)continue;
const c=cameraAt(scene,e.t);const testScene={...scene,camera:[{...c,t:0}],actors:[actor]};
const ledger=eventFile.events.filter(v=>v.actor===actor.id&&(v.phase==='entrance'||v.id===e.id));const isolated=createEngine(testScene,ledger,assets,drawers);
isolated.draw(canvas,Math.max(0,e.t-1/300));const before=canvas.toDataURL('image/png');isolated.draw(canvas,e.t+e.d*(e.mode==='return'?.5:1));
checks.push({actor:actor.id,event:e.id,changed_pixels:before!==canvas.toDataURL('image/png')});}return checks;};window.READY=true;}catch(e){window.FAIL=String(e);throw e;}</script>`;
const server=http.createServer((req,res)=>{
  const u=decodeURIComponent(new URL(req.url,'http://localhost').pathname);let f;
  if(u==='/'){res.setHeader('Content-Type','text/html');res.end(html);return;}
  if(u==='/scene.json'||u==='/events.json'||u==='/art.mjs')f=path.join(project,path.basename(u));
  else if(u==='/engine.mjs')f=path.join(root,'templates/engine.mjs');
  else if(u.startsWith('/fonts/'))f=path.join(runtime.fonts,path.basename(u));
  else if(u.startsWith('/asset/')){f=path.resolve(cfg.assets,u.slice(7));if(!f.startsWith(path.resolve(cfg.assets)+path.sep))f=null;}
  if(!f||!fs.existsSync(f)){res.writeHead(404);res.end('Not found');return;}
  res.setHeader('Content-Type',f.endsWith('.mjs')?'text/javascript':f.endsWith('.json')?'application/json':f.endsWith('.svg')?'image/svg+xml':f.endsWith('.png')?'image/png':'application/octet-stream');fs.createReadStream(f).pipe(res);
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;
const still=arg('--stills',null),times=still?still.split(',').map(Number):Array.from({length:cfg.frames},(_,i)=>i/30);
const dir=path.join(output,still?'review':'frames');fs.mkdirSync(dir,{recursive:true});
// Remove only prior generated numbered frames from this project's output.
if(!still)for(const name of fs.readdirSync(dir))if(/^\d{6}\.jpg$/.test(name))fs.unlinkSync(path.join(dir,name));
const reports=[],errors=[];let done=0,opening=null,visualLoop=null,secondaryAudit=[],assetAudit=[];const started=Date.now();
try{
 const {chromium}=await import(pathToFileURL(runtime.playwright_module).href);
 browser=await chromium.launch({executablePath:runtime.chromium,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const workers=still?1:Math.max(1,Math.min(4,Number(arg('--workers',2))));
 await Promise.all(Array.from({length:workers},async(_,w)=>{
  const page=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});page.on('pageerror',e=>errors.push(String(e)));
  await page.goto(`http://127.0.0.1:${server.address().port}`);await page.waitForFunction(()=>window.READY||window.FAIL,null,{timeout:120000});
  const fail=await page.evaluate(()=>window.FAIL);if(fail)throw Error(fail);
  if(w===0){opening=await page.evaluate(()=>{draw(0);const actual=document.getElementById('c').toDataURL('image/png');draw(0,true);return {actual,background:document.getElementById('c').toDataURL('image/png')};});if(opening.actual!==opening.background)throw Error('Frame zero contains foreground content');opening={background_only:true,pixel_equal:true};
   const sources=await page.evaluate(()=>assetInfo),maxZoom=Math.max(...scene.camera.map(c=>c.zoom));
   assetAudit=scene.actors.filter(a=>a.type==='image').map(a=>{const src=sources.find(s=>s.id===a.asset);if(!src)throw Error('Image source not loaded: '+a.asset);const zoom=maxZoom*(1+(a.depth||0)*.0002);return {actor:a.id,source:src,maxScreenWidth:a.w*zoom,maxScreenHeight:a.h*zoom,upscaled:a.w*zoom>src.width||a.h*zoom>src.height,distorted:Math.abs(a.w/a.h/(src.width/src.height)-1)>.015};});
   if(assetAudit.some(a=>a.upscaled||a.distorted))throw Error('Image upscale/aspect ratio gate failed: '+JSON.stringify(assetAudit.filter(a=>a.upscaled||a.distorted)));
   secondaryAudit=await page.evaluate(()=>auditSecondaries());if(secondaryAudit.some(s=>!s.changed_pixels))throw Error('Unimplemented or invisible secondary action: '+JSON.stringify(secondaryAudit.filter(s=>!s.changed_pixels)));
   if(scene.loop?.enabled){visualLoop=await page.evaluate(t=>{const a=draw(0).camera;const first=document.getElementById('c').toDataURL('image/png');const b=draw(t).camera;return {last_frame_matches_first:first===document.getElementById('c').toDataURL('image/png'),camera_matches:['x','y','zoom','roll'].every(k=>Math.abs((a[k]||0)-(b[k]||0))<1e-6),audio_loop:'separate review required'};},(cfg.frames-1)/30);if(!visualLoop.last_frame_matches_first||!visualLoop.camera_matches)throw Error('Requested visual loop does not return to opening pose and frame');}
  }
  for(let i=w;i<times.length;i+=workers){
   const t=times[i];if(!Number.isFinite(t)||t<0||t>=cfg.frames/30)throw Error('Invalid still time '+t);
   const result=await page.evaluate(t=>{const report=draw(t);return {report,jpeg:document.getElementById('c').toDataURL('image/jpeg',.97).split(',')[1]};},t);
   if(errors.length)throw Error(errors.join('\n'));
   if(still||i%30===0||i===times.length-1)reports.push({t,...result.report});
   fs.writeFileSync(path.join(dir,still?`still-${t.toFixed(3)}.jpg`:`${String(i).padStart(6,'0')}.jpg`),Buffer.from(result.jpeg,'base64'));
   if(++done%90===0||done===times.length)console.log(`${done}/${times.length} frames`);
  }await page.close();
 }));
 const assetHashes=Object.fromEntries(Object.entries(scene.assets||{}).map(([id,file])=>{const f=path.resolve(cfg.assets,file);if(!f.startsWith(path.resolve(cfg.assets)+path.sep))throw Error('Asset escaped directory');return [id,crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex')];}));
 const sourceHash=crypto.createHash('sha256').update(JSON.stringify({scene,events,assetHashes})).update(fs.readFileSync(path.join(project,'art.mjs'))).update(fs.readFileSync(path.join(root,'templates/engine.mjs'))).digest('hex');
 fs.writeFileSync(path.join(output,still?'still-report.json':'render-report.json'),JSON.stringify({frames:done,seconds:(Date.now()-started)/1000,opening,secondaryAudit,assetAudit,assetHashes,visualLoop,sourceHash,errors,samples:reports.sort((a,b)=>a.t-b.t)},null,2));
}finally{if(browser)await browser.close();await new Promise(r=>server.close(r));}
