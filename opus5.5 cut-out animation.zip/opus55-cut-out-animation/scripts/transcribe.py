"""Optional offline ASR. Retains actual backend timestamps; never fabricates alignment."""
import argparse,json,subprocess
from pathlib import Path
import numpy as np
import sherpa_onnx
p=argparse.ArgumentParser();p.add_argument('--audio',type=Path,required=True);p.add_argument('--model-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(a.audio),'-f','f32le','-ac','1','-ar','16000','-']);x=np.frombuffer(raw,np.float32)
r=sherpa_onnx.OfflineRecognizer.from_sense_voice(model=str(a.model_dir/'model.int8.onnx'),tokens=str(a.model_dir/'tokens.txt'),num_threads=4,use_itn=False,language='zh')
s=r.create_stream();s.accept_waveform(16000,x);r.decode_stream(s);result=s.result
times=list(getattr(result,'timestamps',[]) or []);tokens=list(getattr(result,'tokens',[]) or [])
j={'duration':len(x)/16000,'text':result.text,'tokens':tokens,'timestamps':times,'granularity':'token' if times and len(times)==len(tokens) else 'segment','original_voice_preserved':True}
a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'duration':j['duration'],'granularity':j['granularity'],'tokens':len(tokens)},ensure_ascii=False))
if j['granularity']!='token':print('No token timing supplied by this backend. Use another aligner or verified listening anchors before claiming word-accurate sync.')
