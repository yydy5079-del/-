import argparse,json,os,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a=p.parse_args();cfg=json.loads((a.project/'project.json').read_text());out=Path(cfg['output']).resolve();boundary=Path(cfg.get('source_repo',a.project)).resolve()
assert not out.is_relative_to(boundary),'Media output must be outside repository'
assert len(list((out/'frames').glob('*.jpg')))==cfg['frames'],'Frame sequence count differs from expected total'
threads=str(min(4,os.cpu_count() or 2))
def run(cmd):subprocess.run(cmd,check=True)
run(['ffmpeg','-v','warning','-y','-framerate','30','-start_number','0','-i',str(out/'frames/%06d.jpg'),'-frames:v',str(cfg['frames']),'-vf','scale=in_range=pc:out_range=tv:out_color_matrix=bt709','-c:v','libx264','-threads',threads,'-preset','medium','-crf','17','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-color_range','tv','-an',str(out/'picture.mp4')])
run(['ffmpeg','-v','warning','-y','-i',str(out/'mix-premaster.wav'),'-af','loudnorm=I=-14:TP=-1.5:LRA=7','-ar','48000','-c:a','pcm_s24le',str(out/'mix.wav')])
run(['ffmpeg','-v','warning','-y','-i',str(out/'picture.mp4'),'-i',str(out/'mix.wav'),'-c:v','copy','-c:a','aac','-b:a','256k','-ar','48000','-t',str(cfg['frames']/30),'-movflags','+faststart',str(out/'film.mp4')])
run([sys.executable,str(Path(__file__).with_name('verify_video.py')),'--project',str(a.project)])
