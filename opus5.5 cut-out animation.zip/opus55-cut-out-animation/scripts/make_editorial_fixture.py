"""Original engraving-style SVG feature fixture; no reference media copied."""
import argparse,json,math
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a=p.parse_args()
cfg=json.loads((a.project/'project.json').read_text());assert cfg['duration']>=4.8;cfg['mode']='technical-fixture';(a.project/'project.json').write_text(json.dumps(cfg,indent=2)+'\n')
assets=Path(cfg['assets']);assets.mkdir(parents=True,exist_ok=True)
spokes=''.join(f'<path d="M430 334 L{430+112*math.cos(i*math.pi/6):.3f} {334+112*math.sin(i*math.pi/6):.3f}"/>' for i in range(12))
threads=''.join(f'<path d="M538 {y} l65 -13"/>' for y in range(92,310,12))
sheets=''.join(f'<path d="M300 {y} l352 0"/>' for y in range(454,490,5))
svg=f'''<svg xmlns="http://www.w3.org/2000/svg" width="900" height="640" viewBox="0 0 900 640">
<defs><pattern id="h" width="7" height="7" patternUnits="userSpaceOnUse"><path d="M-1 8L8-1" stroke="#39352e" stroke-width=".8"/></pattern><pattern id="dots" width="8" height="8" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1" fill="#655e4d"/></pattern></defs>
<g stroke="#27251f" stroke-width="3" stroke-linejoin="round">
<path d="M185 522L735 522L790 573L141 573Z" fill="#b6ac94"/><path d="M185 522L735 522L790 573L141 573Z" fill="url(#h)"/>
<path d="M207 550v54h73l10-54M652 550l10 54h77v-54" fill="#5c594e"/>
<path d="M226 88h64v437h-64zM667 88h64v437h-64z" fill="#b5ad97"/>
<path d="M252 88h24v437h-24zM693 88h24v437h-24z" fill="url(#h)"/>
<path d="M196 82L728 62L752 106L210 125Z" fill="#c6bda5"/><path d="M196 82L728 62L752 106L210 125Z" fill="url(#h)"/>
<rect x="543" y="92" width="53" height="250" rx="8" fill="#c0b79f"/>{threads}
<path d="M512 135h118v25H512z" fill="#635e50"/>
<path d="M566 153L747 190" stroke-width="14"/><circle cx="752" cy="191" r="18" fill="#504c43"/>
<path d="M315 398h322l28 38H292Z" fill="#b1a78e"/><path d="M315 398h322l28 38H292Z" fill="url(#h)"/>
<path d="M560 309h21v88h-21z" fill="#7b7563"/><ellipse cx="570" cy="397" rx="57" ry="12" fill="#4f4d43"/>
<rect x="295" y="445" width="360" height="48" fill="#e6dfca"/>{sheets}
<path d="M271 497h409l30 27H248Z" fill="#8e8773"/>
<circle cx="430" cy="334" r="126" fill="#d4cbb2"/><circle cx="430" cy="334" r="115" fill="url(#dots)"/>
<circle cx="430" cy="334" r="95" fill="#e6dfcd"/>{spokes}<circle cx="430" cy="334" r="24" fill="#6b6658"/>
<path d="M430 334l-78 59" stroke-width="10"/><circle cx="352" cy="393" r="14" fill="#3f3d34"/>
<path d="M430 334h113" stroke-width="11"/>
<g fill="#3b3931"><circle cx="246" cy="147" r="5"/><circle cx="246" cy="487" r="5"/><circle cx="709" cy="147" r="5"/><circle cx="709" cy="487" r="5"/></g>
<path d="M302 448l343 0" stroke="#f5efdf" stroke-width="4"/>
</g></svg>'''
(assets/'engraving.svg').write_text(svg)
duration=cfg['frames']/30
scene={'duration':duration,'seed':55,'background':{'color':'#E9E3D5'},'assets':{'engraving':'engraving.svg'},'subs':[],
 'camera':[{'t':0,'x':960,'y':540,'zoom':1,'roll':0},{'t':2.4,'x':960,'y':540,'zoom':1,'roll':0},{'t':3.4,'x':1010,'y':490,'zoom':1.06,'roll':0,'control1':[1025,540],'control2':[1045,505]},{'t':duration,'x':1010,'y':490,'zoom':1.06,'roll':0}],
 'actors':[
 {'id':'mount','type':'paper','x':1008,'y':560,'w':760,'h':510,'depth':1,'color':'#CBB38B','important':False},
 {'id':'plate','type':'image','asset':'engraving','x':960,'y':545,'w':680,'h':680*640/900,'depth':4,'matte':{'width':3,'color':'#F7F1E2'},'important':True},
 {'id':'title','type':'text','x':960,'y':185,'size':72,'weight':900,'text':'剪报材质与动作','depth':5,'important':True,'reading':[1.0,2.3]},
 {'id':'label','type':'text','x':960,'y':900,'size':34,'font':'aux','weight':400,'text':'无字雕版素材 · 撕纸揭示 · 弧线观察','depth':5,'important':False,'reading':[1.3,4.6]}]}
def snd(id,kind,offset,duration,stage='contact'):return {'id':id,'kind':kind,'offset':offset,'duration':duration,'stage':stage}
events=[
 {'id':'mount-enter','actor':'mount','phase':'entrance','t':.1,'d':.7,'reveal':{'kind':'wipe','from':'top'},'meaning':'衬纸从纸底揭示','sounds':[snd('mount-paper','paper_slide',0,.6,'sustain')]},
 {'id':'plate-enter','actor':'plate','phase':'entrance','t':.25,'d':.65,'contact':.55,'reveal':{'kind':'tear','from':'left','edge':12},'meaning':'静态雕版以固定种子撕边揭示','sounds':[snd('plate-tear','tear',0,.5,'sustain'),snd('plate-contact','paper_tap',.55,.12)]},
 {'id':'plate-align','actor':'plate','phase':'secondary','t':1.45,'d':.75,'contact':.65,'channel':'dx','toValue':48,'meaning':'图版沿定位边归位，与衬纸组成同一剪报组','sounds':[snd('align-slide','paper_slide',0,.6,'sustain'),snd('align-touch','clasp',.65,.12)]},
 {'id':'title-enter','actor':'title','phase':'entrance','t':.35,'d':.6,'reveal':{'kind':'wipe','from':'left'},'meaning':'代码中文标题平直揭示','sounds':[snd('title-wipe','paper_slide',0,.5,'sustain')]},
 {'id':'title-link','actor':'title','phase':'secondary','t':1.25,'d':.75,'channel':'underline','meaning':'标题与图版建立编辑关系','sounds':[snd('underline','ink',0,.7,'sustain')]},
 {'id':'label-enter','actor':'label','phase':'entrance','t':.7,'d':.5,'meaning':'辅助说明整行稳定出现','sounds':[snd('label-paper','paper_tap',0,.12,'onset')]}]
for name,data in [('scene.json',scene),('events.json',{'events':events})]:(a.project/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
(a.project/'art.mjs').write_text('export const drawers = {};\n')
(a.project/'ART_DIRECTION.md').write_text('# 技术材质检查\n\n原创无字SVG检验图片细纸边、揭示与相机曲线；不是已认可的正式人物或机器美术。\n')
(a.project/'assets.json').write_text(json.dumps({'visual_family':'editorial-photo-engraving-collage','assets':[{'id':'engraving','source':'original procedural SVG feature fixture','no_embedded_text':True,'style':'engraving','parts':[]}]},ensure_ascii=False,indent=2))
print(json.dumps({'actors':len(scene['actors']),'events':len(events),'sounds':sum(len(e['sounds']) for e in events)},indent=2))
