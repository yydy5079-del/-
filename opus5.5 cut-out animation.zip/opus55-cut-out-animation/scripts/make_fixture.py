"""Author a >=4.8s feature fixture in an initialized external project."""
import argparse,json,shutil
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a=p.parse_args()
cfg=json.loads((a.project/'project.json').read_text());assert cfg['duration']>=4.8,'Need at least4.8 seconds for fixture';cfg['mode']='technical-fixture';(a.project/'project.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n')
root=Path(__file__).resolve().parents[1]
scene={'duration':cfg['frames']/30,'seed':55,'background':{'color':'#E9E4D9'},'assets':{},'subs':[],
 'camera':[{'t':0,'x':960,'y':540,'zoom':1,'roll':0},{'t':2.6,'x':960,'y':540,'zoom':1,'roll':0},{'t':3.35,'x':1030,'y':470,'zoom':1.05,'roll':0},{'t':3.75,'x':1030,'y':470,'zoom':1.05,'roll':0},{'t':4.6,'x':980,'y':420,'zoom':1.08,'roll':0}],
 'actors':[
  {'id':'person','type':'custom','drawer':'person','important':True,'x':560,'y':575,'w':330,'h':440,'depth':4},
  {'id':'machine','type':'custom','drawer':'machine','important':True,'x':1230,'y':595,'w':560,'h':425,'depth':7},
  {'id':'title','type':'text','important':True,'x':960,'y':205,'size':68,'weight':900,'text':'剪贴动效检查','depth':8,'reading':[.95,2.5]},
  {'id':'label','type':'text','important':False,'x':1045,'y':900,'font':'aux','weight':400,'size':34,'text':'先入场，再动作；声音跟随接触','depth':8,'reading':[2.1,4.7]},
  {'id':'link','type':'path','important':True,'x':0,'y':0,'w':400,'h':200,'depth':2,'points':[[790,540],[890,500],[955,500]],'color':'#AC392A'}]}
def sound(id,kind,offset,duration,stage='contact',pan=0):return {'id':id,'kind':kind,'offset':offset,'duration':duration,'stage':stage,'pan':pan}
events=[
 {'id':'person-enter','actor':'person','phase':'entrance','t':.12,'d':.65,'contact':.52,'from':{'x':-160,'y':60,'scale':.97,'rotation':-2},'meaning':'人物剪贴滑入并落稳','sounds':[sound('person-slide','paper_slide',0,.5,'onset',-.4),sound('person-touch','paper_tap',.52,.12,pan=-.4)]},
 {'id':'person-point','actor':'person','phase':'secondary','t':1.12,'d':.7,'channel':'point','contact':.5,'meaning':'入场后手臂指向被解释对象','sounds':[sound('sleeve','paper_fold',0,.5,'sustain',-.3),sound('point-end','paper_tap',.5,.12,pan=-.2)]},
 {'id':'machine-enter','actor':'machine','phase':'entrance','t':.5,'d':.75,'contact':.62,'from':{'x':170,'y':80,'scale':.96,'rotation':1},'meaning':'工程物件进入并接触台面','sounds':[sound('machine-slide','air',0,.52,'onset',.3),sound('machine-touch','clasp',.62,.12,pan=.3)]},
 {'id':'machine-feed','actor':'machine','phase':'secondary','t':2.0,'d':1.1,'contact':.4,'channel':'feed','meaning':'纸带进入真实遮挡槽并带动传动部件','sounds':[sound('feed-motor','motor',0,.95,'sustain',.35),sound('feed-contact','relay',.4,.1,pan=.35)]},
 {'id':'title-enter','actor':'title','phase':'entrance','t':.3,'d':.6,'contact':.5,'from':{'y':-60},'meaning':'编辑主标题整行入场','sounds':[sound('title-paper','paper_tap',.5,.12)]},
 {'id':'title-link','actor':'title','phase':'secondary','t':1.2,'d':.8,'channel':'underline','meaning':'下划线建立标题与解释结构的联系','sounds':[sound('title-ink','ink',0,.75,'sustain')]},
 {'id':'label-enter','actor':'label','phase':'entrance','t':1.5,'d':.5,'contact':.4,'from':{'y':30},'meaning':'辅助文字稳定出现','sounds':[sound('label-touch','paper_tap',.4,.1)]},
 {'id':'link-enter','actor':'link','phase':'entrance','t':1.4,'d':.3,'contact':.2,'from':{},'meaning':'关系起点入场','sounds':[sound('link-start','ink',.2,.1)]},
 {'id':'link-trace','actor':'link','phase':'secondary','t':1.85,'d':.8,'channel':'trace','meaning':'从人物手势向物件追踪关系','sounds':[sound('link-draw','ink',0,.78,'sustain')]}]
(a.project/'scene.json').write_text(json.dumps(scene,ensure_ascii=False,indent=2)+'\n');(a.project/'events.json').write_text(json.dumps({'events':events},ensure_ascii=False,indent=2)+'\n')
shutil.copyfile(root/'examples/art.mjs',a.project/'art.mjs')
(a.project/'STORYBOARD.md').write_text('# 技术检查用例\n\n只验证开场、纸片入场、人物关节二次动作、机械进纸、文字和共享声音时间轴。不是新主题成片，也不是完整口播语义同步证明。\n')
print(json.dumps({'actors':len(scene['actors']),'events':len(events),'sounds':sum(len(e['sounds']) for e in events)},ensure_ascii=False))
