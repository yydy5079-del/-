import argparse,hashlib,json,re,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a=p.parse_args();cfg=json.loads((a.project/'project.json').read_text());out=Path(cfg['output']);video=out/'film.mp4'
j=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(video)]));v=next(x for x in j['streams'] if x['codec_type']=='video');au=next(x for x in j['streams'] if x['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],v['codec_name'],v['pix_fmt'],int(v['nb_frames']))==(1920,1080,'30/1','h264','yuv420p',cfg['frames'])
assert au['codec_name']=='aac' and int(au['sample_rate'])==48000
assert not any(x['codec_type']=='subtitle' for x in j['streams'])
assert abs(float(j['format']['duration'])-cfg['frames']/30)<.05
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(video),'-vf','blackdetect=d=0.07:pix_th=0.03:pic_th=0.99','-af','loudnorm=I=-14:TP=-1.5:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
assert 'black_start:' not in r.stderr,'Unexpected black interval'
ld=json.loads(re.findall(r'\{\s*"input_i".*?\}',r.stderr,re.S)[-1]);assert -15<float(ld['input_i'])<-13;assert float(ld['input_tp'])<=-1
sound=json.loads((out/'sound-report.json').read_text());delta=sound['sfx_below_voice_db']
assert delta is None or 7<=delta<=10
render=json.loads((out/'render-report.json').read_text());assert render['opening']['pixel_equal'],'Frame zero foreground contamination'
assert all(x['changed_pixels'] for x in render['secondaryAudit']),'Secondary action not actually drawn'
assert not any(x['upscaled'] or x['distorted'] for x in render.get('assetAudit',[])),'Image asset quality gate failed'
scene=json.loads((a.project/'scene.json').read_text());events=json.loads((a.project/'events.json').read_text())['events']
assert sound['events']==sum(len(e.get('sounds',[])) for e in events),'Shared event sound coverage differs'
if sound['events']:assert delta is not None,'SFX/voice ratio unmeasured'
if scene.get('loop',{}).get('enabled'):
    assert render['visualLoop']['last_frame_matches_first'] and render['visualLoop']['camera_matches']
    import numpy as np
    raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(video),'-vf',f"select='eq(n,0)+eq(n,{cfg['frames']-1})'",'-fps_mode','passthrough','-pix_fmt','rgb24','-f','rawvideo','-'])
    pair=np.frombuffer(raw,np.uint8).reshape(2,1080,1920,3).astype(np.int16)
    mae=float(np.mean(np.abs(pair[0]-pair[1])));assert mae<=2,'Encoded loop boundary differs beyond 2/255 mean RGB tolerance'
    render['visualLoop']['encoded_boundary_rgb_mae_0_255']=mae
report={'resolution':'1920x1080','fps':30,'frames':cfg['frames'],'duration':float(j['format']['duration']),'codec':'H.264 / AAC','decode':'passed','black_frames':False,'subtitles':False,'loudness_lufs':float(ld['input_i']),'true_peak_dbtp':float(ld['input_tp']),'sfx_below_voice_db':delta,'sha256':hashlib.file_digest(video.open('rb'),'sha256').hexdigest(),'visual_review':'separate check required'}
report.update({'opening_background_only':True,'secondary_actions_checked':len(render['secondaryAudit']),'sound_cues':sound['events'],'visual_loop':render.get('visualLoop'),'semantic_and_listening_review':'separate review required'})
(out/'quality-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
