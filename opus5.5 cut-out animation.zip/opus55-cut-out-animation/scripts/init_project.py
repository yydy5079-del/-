"""Initialize a source-only project and measure decoded narration. The agent authors its scenes."""
import argparse, hashlib, json, math, shutil, subprocess
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--audio',type=Path,required=True);p.add_argument('--text',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--source-repo',type=Path);a=p.parse_args()
project=a.project.resolve();out=a.out.resolve();audio=a.audio.resolve();text=a.text.resolve()
assert audio.is_file() and text.is_file(),'Audio and UTF-8 text files are required'
repo=a.source_repo
if not repo:
    anchor=project if project.exists() else project.parent
    while not anchor.exists():anchor=anchor.parent
    r=subprocess.run(['git','-C',str(anchor),'rev-parse','--show-toplevel'],capture_output=True,text=True)
    if r.returncode==0:repo=Path(r.stdout.strip())
if out.is_relative_to(project) or (repo and out.is_relative_to(repo.resolve())):raise SystemExit('OUTPUT must be outside the source repo/project')
if (project/'project.json').exists():raise SystemExit('Project already exists; preserve it or choose another path')
project.mkdir(parents=True,exist_ok=True);out.mkdir(parents=True,exist_ok=True);(out/'objects').mkdir(exist_ok=True)
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(audio),'-f','s16le','-ac','1','-ar','48000','-'])
duration=len(raw)/2/48000;frames=math.ceil(duration*30)
data={'title':project.name,'mode':'production','audio':str(audio),'output':str(out),'source_repo':str(repo.resolve()) if repo else str(project),'assets':str(out/'objects'),'duration':duration,'frames':frames,'fps':30,'width':1920,'height':1080,'audio_sha256':hashlib.sha256(audio.read_bytes()).hexdigest(),'scene':'scene.json','events':'events.json'}
(project/'project.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');shutil.copyfile(text,project/'narration.txt')
(project/'events.json').write_text('{"events": []}\n');(project/'STORYBOARD.md').write_text('# 待 agent 按事件编排的分镜\n\n先对齐实际音频，再编写 scene.json、art.mjs 与 events.json。不得按字数伪造时间戳。\n')
shutil.copyfile(Path(__file__).resolve().parents[1]/'templates/build.sh',project/'build.sh')
print(json.dumps(data,ensure_ascii=False,indent=2))
