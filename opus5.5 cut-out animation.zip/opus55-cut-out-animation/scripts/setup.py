"""Prepare an external cache. No media/dependencies are written into the source repo."""
import argparse, hashlib, json, os, shutil, subprocess, sys, urllib.request, venv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument('--cache', type=Path, required=True)
p.add_argument('--python', dest='python_path', help='Reuse a prepared private Python interpreter')
p.add_argument('--playwright-module', type=Path, help='Reuse playwright-core/index.mjs')
a = p.parse_args(); cache = a.cache.resolve()
repo = subprocess.run(['git', '-C', str(ROOT), 'rev-parse', '--show-toplevel'], capture_output=True, text=True)
if repo.returncode == 0 and cache.is_relative_to(Path(repo.stdout.strip()).resolve()):
    raise SystemExit('Cache must remain outside the source repository')
cache.mkdir(parents=True, exist_ok=True); fonts = cache/'fonts'; fonts.mkdir(exist_ok=True)
for f in json.loads((ROOT/'fonts.json').read_text())['fonts']:
    target = fonts/f['file']
    if not target.exists():
        tmp = target.with_suffix('.download')
        with urllib.request.urlopen(f['url'], timeout=90) as r, tmp.open('wb') as w: shutil.copyfileobj(r,w)
        if hashlib.sha256(tmp.read_bytes()).hexdigest() != f['sha256']:
            tmp.unlink(); raise SystemExit('Downloaded font checksum mismatch: '+f['file'])
        tmp.replace(target)
    if hashlib.sha256(target.read_bytes()).hexdigest() != f['sha256']:
        raise SystemExit('Cached font differs from pinned source: '+f['file'])

python = a.python_path
if not python:
    env = cache/'python'
    if not (env/'bin/python').exists(): venv.EnvBuilder(with_pip=True).create(env)
    python = str(env/'bin/python')
deps = ['numpy', 'scipy', 'PIL', 'fontTools']
check = subprocess.run([python,'-c',';'.join('import '+d for d in deps)], capture_output=True)
if check.returncode:
    subprocess.run([python,'-m','pip','install','--disable-pip-version-check','numpy==2.2.6','scipy==1.15.3','Pillow==11.3.0','fonttools==4.61.1'],check=True)
module = a.playwright_module
if not module:
    module=cache/'node/node_modules/playwright-core/index.mjs'
    if not module.exists(): subprocess.run(['npm','install','--prefix',str(cache/'node'),'--no-audit','--no-fund','playwright-core@1.58.2'],check=True)
chromium = next((shutil.which(x) for x in ['chromium','chromium-browser','google-chrome'] if shutil.which(x)), None)
runtime = {'cache':str(cache),'fonts':str(fonts),'python':python,'playwright_module':str(module.resolve()),'chromium':chromium,'ffmpeg':shutil.which('ffmpeg'),'ffprobe':shutil.which('ffprobe')}
(cache/'runtime.json').write_text(json.dumps(runtime,indent=2)+'\n')
subprocess.run([python,str(ROOT/'scripts/check_fonts.py'),'--fonts',str(fonts)],check=True)
missing=[x for x in ['chromium','ffmpeg','ffprobe'] if not runtime[x]]
print(json.dumps(runtime,indent=2))
if missing: raise SystemExit('Agent must install system tools through the supported package manager: '+', '.join(missing))
