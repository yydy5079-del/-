"""Check real failure modes in the shared visual/sound event ledger."""
import argparse, json, math
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a=p.parse_args()
cfg=json.loads((a.project/'project.json').read_text());scene=json.loads((a.project/'scene.json').read_text());events=json.loads((a.project/'events.json').read_text())['events']
errors=[];warnings=[]
def check(ok,message):
    if not ok:errors.append(message)
check((cfg['width'],cfg['height'],cfg['fps'])==(1920,1080,30),'Expected native 1080p30')
check(cfg['frames']==math.ceil(cfg['duration']*30),'Frame count must follow decoded voice')
check(abs(scene['duration']-cfg['frames']/30)<1e-7,'Scene duration mismatch')
check(not scene.get('subs'),'No subtitle layer permitted')
actors={x['id']:x for x in scene['actors']};ids={x['id']:x for x in events}
check(len(actors)==len(scene['actors']),'Duplicate actor id');check(len(ids)==len(events),'Duplicate event id')
camera=scene['camera'];check(camera and camera[0]['t']==0,'Camera must define frame zero')
for i,c in enumerate(camera):
    check(c['zoom']>0 and all(math.isfinite(c[k]) for k in ['t','x','y','zoom']),'Invalid camera keyframe')
    check(abs(c.get('roll',0))<=2,'Keep reading plane approximately upright')
    if i:check(c['t']>camera[i-1]['t'],'Camera timestamps must be increasing')
minzoom=min(c['zoom'] for c in camera)
for actor in actors.values():
    es=[e for e in events if e['actor']==actor['id']];ent=[e for e in es if e['phase']=='entrance'];second=[e for e in es if e['phase']=='secondary']
    check(len(ent)==1,'Exactly one entrance required for '+actor['id'])
    if ent:check(ent[0]['t']>=1/30-1e-8,'Actor visible/prepared at forbidden frame zero: '+actor['id'])
    if actor.get('important'):
        check(bool(second),'Missing semantic secondary action: '+actor['id'])
        if ent:
            for e in second:check(e['t']>=ent[0]['t']+ent[0]['d']-1e-8,'Secondary starts before entrance settles: '+e['id'])
        for e in second:check(e.get('channel') not in ['scale','rotation','pulse'],'Idle transform is not sufficient semantic secondary action: '+e['id'])
    if actor['type']=='text':
        check(actor.get('size',0)*minzoom>=30,'Text too small on screen: '+actor['id'])
        if actor.get('font')=='aux':
            check(actor.get('weight',400)==400,'Auxiliary font must be real Regular 400')
            check(all(not e.get('from',{}).get('rotation') and e.get('channel') not in ['rotation','scale'] for e in es),'Auxiliary text distortion prohibited')
        reading=actor.get('reading');check(reading and reading[1]-reading[0]>=1.2,'Text needs >=1.2 seconds stable reading: '+actor['id'])
sound_ids=set()
for e in events:
    check(e['actor'] in actors,'Unknown actor '+e['actor'])
    check(e['phase'] in ['entrance','secondary','accent','exit'],'Unknown event phase: '+e['id'])
    check(e['t']>=0 and e['d']>0 and e['t']+e['d']<=scene['duration']+1e-7,'Event outside movie: '+e['id'])
    check(bool(e.get('meaning')),'Document semantic meaning: '+e['id'])
    contact=e.get('contact');check(contact is None or 0<=contact<=e['d'],'Contact outside event: '+e['id'])
    important=actors.get(e['actor'],{}).get('important')
    sounds=e.get('sounds',[])
    if important:check(bool(sounds),'Important event missing sound: '+e['id'])
    if contact is not None and important:check(any(s.get('stage')=='contact' for s in sounds),'Contact event has no contact sound: '+e['id'])
    for s in sounds:
        check(s['id'] not in sound_ids,'Duplicate sound cue: '+s['id']);sound_ids.add(s['id'])
        start=e['t']+s.get('offset',0);end=start+s['duration']
        check(0<=start<end<=scene['duration']+1e-7,'Sound outside movie: '+s['id'])
        check(bool(s.get('src') or s.get('kind')),'Missing sound source: '+s['id'])
        if s.get('stage')=='contact':check(contact is not None and abs(s.get('offset',0)-contact)<=1/30+1e-8,'Sound/contact frame mismatch: '+s['id'])
    anchor=e.get('anchor')
    if anchor and anchor.get('confirmed'):
        actual=e['t']+(contact or 0) if anchor.get('hit')=='contact' else e['t']
        check(abs(actual-anchor['time'])<=.10+1e-8,'Keyword timing mismatch: '+e['id'])
    elif e['phase']=='secondary':warnings.append('Keyword alignment not independently confirmed: '+e['id'])
    for dep in e.get('depends_on',[]):
        check(dep in ids,'Unknown causal dependency '+dep)
        if dep in ids:check(ids[dep]['t']+ids[dep].get('contact',ids[dep]['d'])<=e['t']+1e-8,'Effect precedes cause: '+e['id'])
visiting=set();visited=set()
def visit(i):
    if i in visiting:errors.append('Causal dependency cycle: '+i);return
    if i in visited:return
    visiting.add(i)
    for dep in ids[i].get('depends_on',[]):
        if dep in ids:visit(dep)
    visiting.remove(i);visited.add(i)
for i in ids:visit(i)
print(json.dumps({'passed':not errors,'actors':len(actors),'events':len(events),'sounds':len(sound_ids),'errors':errors,'warnings':warnings,'visual_review_required':True},ensure_ascii=False,indent=2))
if errors:raise SystemExit(1)
