"""Check real failure modes in the shared visual/sound event ledger."""
import argparse, json, math
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a=p.parse_args()
cfg=json.loads((a.project/'project.json').read_text());scene=json.loads((a.project/'scene.json').read_text());events=json.loads((a.project/'events.json').read_text())['events']
errors=[];warnings=[]
production=cfg.get('mode','production')=='production'
def check(ok,message):
    if not ok:errors.append(message)
check((cfg['width'],cfg['height'],cfg['fps'])==(1920,1080,30),'Expected native 1080p30')
check(cfg.get('mode','production') in ['production','technical-fixture'],'Unknown project mode')
check(cfg['frames']==math.ceil(cfg['duration']*30),'Frame count must follow decoded voice')
check(abs(scene['duration']-cfg['frames']/30)<1e-7,'Scene duration mismatch')
check(not scene.get('subs'),'No subtitle layer permitted')
actors={x['id']:x for x in scene['actors']};ids={x['id']:x for x in events}
check(len(actors)==len(scene['actors']),'Duplicate actor id');check(len(ids)==len(events),'Duplicate event id')
camera=scene['camera'];check(camera and camera[0]['t']==0,'Camera must define frame zero')
alignment={};keywords={}
if production:
    alignment_file=a.project/'alignment.json'
    check(alignment_file.is_file(),'Production requires actual alignment.json')
    if alignment_file.is_file():
        alignment=json.loads(alignment_file.read_text());check(alignment.get('audio_sha256')==cfg['audio_sha256'],'Alignment belongs to another voice file')
        check(abs(alignment.get('decoded_duration',-1)-cfg['duration'])<=1/30,'Alignment duration differs from actual audio')
        for phrase in alignment.get('phrases',[]):
            for k in phrase.get('keywords',[]):
                check(k.get('method') in ['forced-align','asr-reviewed','manual-reviewed'],'Keyword needs a recorded actual review method: '+str(k.get('id')))
                check(isinstance(k.get('id'),str) and bool(k.get('id')) and bool(k.get('text')),'Keyword needs id/text')
                check(isinstance(k.get('time'),(int,float)) and 0<=k['time']<cfg['duration'],'Keyword time outside original voice')
                check(k.get('id') not in keywords,'Duplicate keyword id');keywords[k.get('id')]=k
    art_file=a.project/'ART_DIRECTION.md';check(art_file.is_file(),'Production requires editorial collage art direction, not technical fixture artwork')
    asset_file=a.project/'assets.json';check(asset_file.is_file(),'Production requires source/no-text/parts manifest')
    if asset_file.is_file():
        manifest=json.loads(asset_file.read_text());check(manifest.get('visual_family')=='editorial-photo-engraving-collage','Wrong visual family: use photo/engraving cut-out editorial collage')
        check(bool(manifest.get('assets')),'Production asset manifest is empty')
        for asset in manifest.get('assets',[]):
            check(bool(asset.get('source')) and asset.get('no_embedded_text') is True,'Asset source/no-text check missing: '+str(asset.get('id')))
for i,c in enumerate(camera):
    check(c['zoom']>0 and all(math.isfinite(c[k]) for k in ['t','x','y','zoom']),'Invalid camera keyframe')
    check(abs(c.get('roll',0))<=2,'Keep reading plane approximately upright')
    if i:check(c['t']>camera[i-1]['t'],'Camera timestamps must be increasing')
    if c.get('control1') is not None or c.get('control2') is not None:
        check(all(isinstance(c.get(k),list) and len(c[k])==2 and all(isinstance(v,(int,float)) and math.isfinite(v) for v in c[k]) for k in ['control1','control2']),'Bezier camera needs two finite 2D controls')
minzoom=min(c['zoom'] for c in camera)
for actor in actors.values():
    es=[e for e in events if e['actor']==actor['id']];ent=[e for e in es if e['phase']=='entrance'];second=[e for e in es if e['phase']=='secondary']
    check(len(ent)==1,'Exactly one entrance required for '+actor['id'])
    if ent:check(ent[0]['t']>=1/30-1e-8,'Actor visible/prepared at forbidden frame zero: '+actor['id'])
    if actor.get('important'):
        check(bool(second),'Missing semantic secondary action: '+actor['id'])
        if ent:
            for e in second:check(e['t']>=ent[0]['t']+ent[0]['d']-1e-8,'Secondary starts before entrance settles: '+e['id'])
        for e in second:check(e.get('channel') not in ['scale','rotation','pulse'],'Idle transform is not sufficient semantic secondary action: '+e['id'])
    if actor['type']=='text':
        check(actor.get('size',0)*minzoom>=30,'Text too small on screen: '+actor['id'])
        if actor.get('font')=='aux':
            check(actor.get('weight',400)==400,'Auxiliary font must be real Regular 400')
            check(all(not e.get('from',{}).get('rotation') and e.get('channel') not in ['rotation','scale'] for e in es),'Auxiliary text distortion prohibited')
        reading=actor.get('reading');check(reading and reading[1]-reading[0]>=1.2,'Text needs >=1.2 seconds stable reading: '+actor['id'])
sound_ids=set()
for e in events:
    check(e['actor'] in actors,'Unknown actor '+e['actor'])
    check(e['phase'] in ['entrance','secondary','accent','exit'],'Unknown event phase: '+e['id'])
    check(e['t']>=0 and e['d']>0 and e['t']+e['d']<=scene['duration']+1e-7,'Event outside movie: '+e['id'])
    check(bool(e.get('meaning')),'Document semantic meaning: '+e['id'])
    if e.get('reveal'):
        check(e['phase']=='entrance','Reveal mask belongs to entrance: '+e['id'])
        check(e['reveal'].get('kind') in ['tear','wipe'] and e['reveal'].get('from') in ['left','right','top','bottom'],'Unknown reveal recipe: '+e['id'])
    contact=e.get('contact');check(contact is None or 0<=contact<=e['d'],'Contact outside event: '+e['id'])
    important=actors.get(e['actor'],{}).get('important')
    sounds=e.get('sounds',[])
    if important:check(bool(sounds),'Important event missing sound: '+e['id'])
    if contact is not None and important:check(any(s.get('stage')=='contact' for s in sounds),'Contact event has no contact sound: '+e['id'])
    for s in sounds:
        check(s['id'] not in sound_ids,'Duplicate sound cue: '+s['id']);sound_ids.add(s['id'])
        start=e['t']+s.get('offset',0);end=start+s['duration']
        check(0<=start<end<=scene['duration']+1e-7,'Sound outside movie: '+s['id'])
        check(bool(s.get('src') or s.get('kind')),'Missing sound source: '+s['id'])
        if s.get('stage')=='contact':check(contact is not None and abs(s.get('offset',0)-contact)<=1/30+1e-8,'Sound/contact frame mismatch: '+s['id'])
    anchor=e.get('anchor')
    if anchor and anchor.get('confirmed'):
        actual=e['t']+(contact or 0) if anchor.get('hit')=='contact' else e['t']
        check(abs(actual-anchor['time'])<=.10+1e-8,'Keyword timing mismatch: '+e['id'])
    elif e['phase']=='secondary':
        if production and important:errors.append('Production semantic action requires reviewed keyword anchor: '+e['id'])
        else:warnings.append('Keyword alignment not independently confirmed: '+e['id'])
    if production and important and e['phase']=='secondary' and anchor and anchor.get('confirmed'):
        keyword=keywords.get(anchor.get('keyword_id'));check(keyword is not None,'Anchor keyword missing from actual alignment: '+e['id'])
        if keyword:check(abs(keyword['time']-anchor['time'])<=1/30+1e-8,'Anchor differs from reviewed keyword: '+e['id'])
    for dep in e.get('depends_on',[]):
        check(dep in ids,'Unknown causal dependency '+dep)
        if dep in ids:check(ids[dep]['t']+ids[dep].get('contact',ids[dep]['d'])<=e['t']+1e-8,'Effect precedes cause: '+e['id'])
visiting=set();visited=set()
def visit(i):
    if i in visiting:errors.append('Causal dependency cycle: '+i);return
    if i in visited:return
    visiting.add(i)
    for dep in ids[i].get('depends_on',[]):
        if dep in ids:visit(dep)
    visiting.remove(i);visited.add(i)
for i in ids:visit(i)
print(json.dumps({'passed':not errors,'mode':cfg.get('mode','production'),'actors':len(actors),'events':len(events),'sounds':len(sound_ids),'errors':errors,'warnings':warnings,'visual_review_required':True},ensure_ascii=False,indent=2))
if errors:raise SystemExit(1)
