// Original deterministic 2D/2.5D cut-out compositor. All times are seconds.
export const smooth = u => { u=Math.max(0,Math.min(1,u));return u*u*u*(u*(u*6-15)+10); };
const mix=(a,b,u)=>a+(b-a)*u;
function random(seed=43){return()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};}
export function cameraAt(scene,t){
  const keys=scene.camera;
  if(t<=keys[0].t)return {...keys[0]};
  for(let i=1;i<keys.length;i++)if(t<=keys[i].t){
    const a=keys[i-1],b=keys[i],u=smooth((t-a.t)/(b.t-a.t));
    return {x:mix(a.x,b.x,u),y:mix(a.y,b.y,u),zoom:Math.exp(mix(Math.log(a.zoom),Math.log(b.zoom),u)),roll:mix(a.roll||0,b.roll||0,u)};
  }
  return {...keys.at(-1)};
}
export function stateAt(actor,events,t){
  const es=events.filter(e=>e.actor===actor.id).sort((a,b)=>a.t-b.t);
  const enter=es.find(e=>e.phase==='entrance');
  const u=enter?smooth((t-enter.t)/enter.d):0;
  const f=enter?.from||{};
  const state={visible:u,entranceProgress:u,dx:(f.x||0)*(1-u),dy:(f.y||0)*(1-u),scale:mix(f.scale??1,1,u),rotation:(f.rotation||0)*(1-u),channels:{}};
  for(const e of es){
    if(e.phase==='entrance'||t<e.t)continue;
    let v=smooth((t-e.t)/e.d);
    if(e.mode==='return')v=Math.sin(Math.PI*v);
    const amount=mix(e.fromValue??0,e.toValue??1,v);
    if(e.phase==='exit')state.visible*=1-v;
    else if(e.channel==='dx')state.dx+=amount;
    else if(e.channel==='dy')state.dy+=amount;
    else if(e.channel==='scale')state.scale*=amount;
    else if(e.channel==='rotation')state.rotation+=amount;
    else state.channels[e.channel||'action']=amount;
  }
  return state;
}
export function createEngine(scene,events,assets,drawers={}){
  const pattern=document.createElement('canvas');pattern.width=480;pattern.height=480;
  const p=pattern.getContext('2d');p.fillStyle=scene.background?.color||'#ECE7DC';p.fillRect(0,0,480,480);
  const rng=random(scene.seed||43);
  for(let i=0;i<9000;i++){p.fillStyle=`rgba(${rng()>.5?'255,255,255':'74,61,43'},${.015+rng()*.025})`;p.fillRect(rng()*480,rng()*480,1+rng()*2,1);}
  const outlines=new Map();
  function paperPath(a){
    if(outlines.has(a.id))return outlines.get(a.id);
    const r=random((scene.seed||43)+[...a.id].reduce((n,c)=>n+c.charCodeAt(0),0));
    const q=new Path2D(),w=a.w,h=a.h,n=18,edge=Math.min(w,h)*.009;
    q.moveTo(-w/2,-h/2);
    for(let i=1;i<=n;i++)q.lineTo(-w/2+w*i/n,-h/2+(r()-.5)*edge);
    for(let i=1;i<=n;i++)q.lineTo(w/2+(r()-.5)*edge,-h/2+h*i/n);
    for(let i=1;i<=n;i++)q.lineTo(w/2-w*i/n,h/2+(r()-.5)*edge);
    for(let i=1;i<=n;i++)q.lineTo(-w/2+(r()-.5)*edge,h/2-h*i/n);
    q.closePath();outlines.set(a.id,q);return q;
  }
  function drawActor(ctx,a,s,t){
    if(a.type==='paper'){
      ctx.fillStyle=a.color||'#F9F6EC';ctx.fill(paperPath(a));
      ctx.shadowColor='transparent';ctx.strokeStyle='rgba(49,43,32,.16)';ctx.lineWidth=.8;ctx.stroke(paperPath(a));
    }else if(a.type==='text'){
      ctx.shadowColor='transparent';ctx.fillStyle=a.color||'#242421';
      ctx.font=`${a.weight||(a.font==='aux'?400:700)} ${a.size}px "${a.font==='aux'?'Alibaba PuHuiTi':'Noto Sans SC'}"`;
      ctx.textAlign=a.align||'center';ctx.textBaseline='middle';ctx.fillText(a.text,0,0);
      if(s.channels.underline){const width=ctx.measureText(a.text).width;ctx.strokeStyle=a.accent||'#AE3328';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(-width/2,a.size*.65);ctx.lineTo(-width/2+width*s.channels.underline,a.size*.65);ctx.stroke();}
    }else if(a.type==='image'){
      const image=assets[a.asset];if(!image)throw Error('Missing image: '+a.asset);
      ctx.drawImage(image,-a.w/2,-a.h/2,a.w,a.h);
    }else if(a.type==='path'){
      const pts=a.points;const progress=s.channels.trace??0;
      ctx.shadowColor='transparent';ctx.strokeStyle=a.color||'#AE3328';ctx.lineWidth=a.lineWidth||7;ctx.lineJoin='round';ctx.lineCap='round';
      ctx.fillStyle=a.color||'#AE3328';ctx.beginPath();ctx.arc(pts[0][0],pts[0][1],7,0,Math.PI*2);ctx.fill();
      const lengths=pts.slice(1).map((v,i)=>Math.hypot(v[0]-pts[i][0],v[1]-pts[i][1]));let left=lengths.reduce((a,b)=>a+b,0)*progress;
      ctx.beginPath();ctx.moveTo(...pts[0]);
      for(let i=0;i<lengths.length&&left>0;i++){const u=Math.min(1,left/lengths[i]);ctx.lineTo(mix(pts[i][0],pts[i+1][0],u),mix(pts[i][1],pts[i+1][1],u));left-=lengths[i];}ctx.stroke();
    }else if(a.type==='custom'){
      if(!drawers[a.drawer])throw Error('Missing project drawer: '+a.drawer);
      drawers[a.drawer](ctx,a,s,assets,t);
    }else throw Error('Unknown actor type '+a.type);
  }
  return {
    draw(canvas,t,{backgroundOnly=false}={}){
      const ctx=canvas.getContext('2d');ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;ctx.shadowColor='transparent';ctx.fillStyle=ctx.createPattern(pattern,'repeat');ctx.fillRect(0,0,1920,1080);
      if(backgroundOnly)return;
      const c=cameraAt(scene,t);
      for(const a of [...scene.actors].sort((a,b)=>(a.depth||0)-(b.depth||0))){
        const s=stateAt(a,events,t);if(s.visible<=.000001)continue;
        const zoom=c.zoom*(1+(a.depth||0)*.0002);
        ctx.save();ctx.translate(960,540);ctx.rotate((c.roll||0)*Math.PI/180);ctx.scale(zoom,zoom);ctx.translate(-c.x,-c.y);
        ctx.translate(a.x+s.dx,a.y+s.dy);ctx.rotate(s.rotation*Math.PI/180);ctx.scale(s.scale,s.scale);ctx.globalAlpha=s.visible;
        const lift=(1-s.visible)*16+(a.depth||0)*.08;ctx.shadowColor='rgba(39,31,20,.22)';ctx.shadowOffsetX=5+lift*.2;ctx.shadowOffsetY=7+lift*.45;ctx.shadowBlur=10+lift*.5;
        drawActor(ctx,a,s,t);ctx.restore();
      }
    },
    review(t){return {camera:cameraAt(scene,t),actors:scene.actors.map(a=>({id:a.id,important:!!a.important,...stateAt(a,events,t)}))};}
  };
}
