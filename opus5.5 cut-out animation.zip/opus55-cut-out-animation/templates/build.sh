#!/usr/bin/env bash
set -euo pipefail
: "${SKILL_DIR:?Set SKILL_DIR to the installed skill directory}"
: "${RUNTIME_JSON:?Set RUNTIME_JSON to external cache/runtime.json}"
PROJECT_DIR="${PROJECT_DIR:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)}"
CUTOUT_PYTHON="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["python"])' "$RUNTIME_JSON")"
CUTOUT_FONTS="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["fonts"])' "$RUNTIME_JSON")"
"$CUTOUT_PYTHON" "$SKILL_DIR/scripts/validate.py" --project "$PROJECT_DIR"
"$CUTOUT_PYTHON" "$SKILL_DIR/scripts/check_fonts.py" --fonts "$CUTOUT_FONTS" --text "$PROJECT_DIR/narration.txt"
node "$SKILL_DIR/scripts/render.mjs" --project "$PROJECT_DIR" --runtime "$RUNTIME_JSON"
"$CUTOUT_PYTHON" "$SKILL_DIR/scripts/mix_audio.py" --project "$PROJECT_DIR"
"$CUTOUT_PYTHON" "$SKILL_DIR/scripts/encode.py" --project "$PROJECT_DIR"
