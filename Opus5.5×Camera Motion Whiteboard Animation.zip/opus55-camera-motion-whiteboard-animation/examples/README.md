# 字体与流水线检查

在仓库外准备一段至少 2 秒的测试口播和同内容文本，用 init_project.py 建立一次性项目，再运行 font_check_scene.py。

```bash
python3 "$SKILL_DIR/scripts/init_project.py" --project /tmp/whiteboard-font-check \
  --audio /external/test-voice.wav --text /external/test-text.txt --out /external/font-check-output
python3 "$SKILL_DIR/scripts/font_check_scene.py" --project /tmp/whiteboard-font-check
SKILL_DIR="$SKILL_DIR" RUNTIME_JSON="$CACHE_DIR/runtime.json" \
  PROJECT_DIR=/tmp/whiteboard-font-check bash /tmp/whiteboard-font-check/build.sh
```

检查目标：四条辅助描述由真正的 Alibaba PuHuiTi Regular 400 整行排版，笔画与基线稳定；源字号48×zoom0.82≈39.4屏幕像素；结尾局部区域明确；1080p30、H.264/AAC、音效活动窗口约低8dB、完整解码通过。

这是技术验收用例，不代表一支科普片的分镜质量。不得将“中文排版检查”示例重复交给用户当作新主题成片。
