# 口播与声音

输入原声先通过 FFmpeg 解码到固定采样率 PCM，测量解码样本数、峰值、响度、声道、时长与尾部。不得只用容器标称时长决定画面长度。

优先复用当前环境的可靠 ASR/强制对齐。可选 SenseVoice（sherpa-onnx）模型：官方发布 https://github.com/k2-fsa/sherpa-onnx/releases/tag/asr-models ，选择 `sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17`。模型留在外部缓存，校验官方提供的摘要/文件信息。若后端没有词级时间戳，必须标为句级并改用可用对齐方法，不能匀分字数冒充精准同步。模型与 Python 包为可选依赖，字体检查不安装大型 ASR 模型。

主音效与口播 −8 dB 是同一活动窗口内的 RMS 比值，不是对两个文件独立看整体响度，也不是将音效音量旋钮设成 −8 dB。短点击声另检查峰值和刺耳程度。音效不能盖过辅音，不在每个字间强行塞提示音。

混音顺序：保留原声 → 生成事件 Foley stem → 按对应有人声窗口校准音量 → 必要时平滑 duck → 加可选轻音乐 → 统一响度及峰值处理 → AAC → 复核。所有归一化对混合后的整体信号进行，保留声部相对关系；不要分别把音效、口播归一化到同一 LUFS。

以 `cues.json` 保存事件，例如：

```json
{"events":[{"time":1.2,"kind":"paper","duration":0.24,"pan":-0.15},{"time":1.42,"kind":"magnet","duration":0.12,"pan":-0.15},{"time":2.1,"kind":"pen","duration":0.32,"pan":0.1}]}
```

模板提供基础 paper/magnet/pen/mechanical 声音。每一条事件必须来自画面动作，程序音效不等于最终声音设计。提问前适度收声，末尾留出尾音，不突然切断口播。

输出保留 voice-stem、sfx-stem、mix-premaster 和 sound-report，便于后续修改。无声窗口不用于计算主音效与口播的比例；不能因没有有效窗口而伪造“8 dB 已通过”。无法测量时记录未通过并调整音效位置或测量窗口。
