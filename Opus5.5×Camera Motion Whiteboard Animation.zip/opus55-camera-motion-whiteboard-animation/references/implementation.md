# 可执行模板接口

本包提供稳定的 Canvas/2.5D 白板引擎。Remotion/SVG 也可以使用，但须落实同样的同步、字体与运镜规范。模板并非自动理解主题的替字视频；agent 要根据原文编写 scene.json 与对象素材。

## 环境与项目

```bash
python3 "$SKILL_DIR/scripts/setup.py" --cache /absolute/external/cache
python3 "$SKILL_DIR/scripts/init_project.py" --project /absolute/source/project \
  --audio /absolute/input/voice.mp3 --text /absolute/input/narration.txt \
  --out /absolute/external/output --source-repo /absolute/source
```

设置脚本可通过 `--python` 和 `--playwright-module` 复用已有私有依赖，版本和实际路径保存在外部 runtime.json。Chromium/FFmpeg 不可用时返回明确缺项，agent 继续通过该环境支持的安装方式完成。不得把环境未就绪说成安装成功。

项目源码：project.json、narration.txt、alignment.json、STORYBOARD.md、scene.json、cues.json、build.sh、资产生成代码。外部输出：objects/、frames/、review/、字体、音频、film.mp4 和质量报告。

## scene.json

```json
{
  "dur": 6.0,
  "board": {"w": 3200, "h": 2200, "texScale": 0.27, "ghosts": 15, "seed": 43},
  "hand": 0,
  "sheen": 0.02,
  "cam": {"x": 1400, "y": 1000, "z": 0.9, "roll": 0, "moves": []},
  "elements": [
    {"id":"name","type":"tag","text":"生产验证","xy":[600,500],"size":90,"z":16,
      "arrive":{"t":0,"kind":"drop","d":0.35,"lift":45}},
    {"id":"description","type":"ink","kind":"write","font":"aux","role":"aux",
      "text":"观察实际生产结果","weight":400,"size":44,"xy":[650,740],
      "t":0.2,"d":0.2,"reading":[0.5,2.0],"color":"#454C55"},
    {"id":"relation","type":"ink","kind":"line","points":[[800,900],[1300,900]],
      "t":1.5,"d":0.5,"lw":8,"color":"blue","arrow":true}
  ],
  "subs": [],
  "review": {"endingEvent":"当前生产验证事件","final_frame_region":[0,0,3000,2200]}
}
```

以上是接口例子，不可直接冒充新片分镜。`dur` 必须等于实际 `frames/30`。

`cam.moves` 字段：`t,d,dx,dy,dl,dr,a,b`。dx/dy/dr 为相对上一个目标相机状态的增量，`dl=log(newZoom/oldZoom)`，a/b 默认≥2。不能将绝对坐标误传成 dx/dy。

`tag` 使用 Noto Sans SC 700，自带实体纸边与磁钉；核心 `ink/write` 使用 `font:"sc",weight:900`；辅助 `ink/write` 使用 `font:"aux",role:"aux",weight:400`。稳定文字默认无逐字扰动。只有非必要装饰笔记可显式 `handLetter:true`，辅助文字始终忽略该分支并由校验器拒绝。

透明素材：`type:"print",src:"asset-id",xy:[...],w:...`，对应外部 objects/asset-id.png 与 asset-id.json。元信息至少 `{"anchors":{}}`。图片由 agent 原创代码生成或从有许可来源获取，不能把旧电影的人物、工厂固定用于所有主题。

卡片：`type:"card",xy,w,h,lines:[{text,size,x,y,font,weight,color}]`，卡片文字的 x/y 为局部位置。辅助行仍用 font:aux、weight:400。箭头、环线、材质与摄影机实现见 templates/kit/board.js。

## 预览、渲染与复现

```bash
node "$SKILL_DIR/scripts/render.mjs" --project "$PROJECT_DIR" --runtime "$CACHE_DIR/runtime.json" --stills 0.5,1.5
SKILL_DIR="$SKILL_DIR" RUNTIME_JSON="$CACHE_DIR/runtime.json" PROJECT_DIR="$PROJECT_DIR" bash "$PROJECT_DIR/build.sh"
```

模板以 project.json 的帧数全新生成对应帧，避免过期缓存混入；完整帧目录只应属于一个项目版本。修改时可扩展基于源码/资产/字体哈希的缓存，但必须验证失效逻辑。render-report 保存实际相机、文字边界和资产分辨率样本；文字边界也需要人工审视，不只数值通过。

初始性能检查用代表性局部、最快镜头和结尾。优先减少画外绘制、缓存静态材质、限制渲染并发；不要以 24fps 再转 30fps、480p 放大或大面积模糊节省时间。服务器只监听本机且在任务结束后关闭，不对外开放交互 UI。
