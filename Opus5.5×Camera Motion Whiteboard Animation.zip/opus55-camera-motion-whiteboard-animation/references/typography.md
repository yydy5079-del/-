# 字体与文字防变形

## 明确角色

主标题/标签：Noto Sans SC 700；核心数字/关键词：Noto Sans SC 900；辅助描述：Alibaba PuHuiTi Regular 400。辅助字包括说明、单位说明、细分类、来源简注；不能因内容短而改成手写体。

旧片辅助字的问题来自 marker 排版分支中的逐字 rotation、baseline jitter、scale jitter、笔画描边与低对比度叠加。只改 font-family 不足以修正。修复分支必须整行一次 fillText 或原生 SVG/HTML 文本排版，`font-synthesis:none`，实际字重 400，baseline 固定，letter spacing 默认 0，不调用逐字变形和 strokeText。

对修复引擎的辅助描述使用：

```json
{"id":"aux-1","type":"ink","kind":"write","font":"aux","role":"aux","weight":400,"text":"制造业深度应用","xy":[700,600],"size":44,"t":1.2,"d":0.2,"color":"#454C55","reading":[1.5,3.0]}
```

其中 `reading` 是在屏幕上完整清楚可读的区间。不要让清晰期落在大幅运镜中。按最远阅读镜头检查字号；若 zoom=0.6，world font size 至少 50，建议 54–66。若空间不够，减少文案或调整局部构图，不压扁字形。

画面安全边距默认左右各 96 px、上下各 54 px。辅助行与标题卡之间留足高度，不能压在阴影、卡边或工程模型后面。背景对比度至少 4.5:1，目标 7:1。高斯模糊、纹理、透明纸片投影不直接叠在字形上。

## 字体加载门槛

1. `scripts/setup.py` 从 fonts.json 指定的固定提交下载外部缓存，SHA-256 不匹配则失败，不静默更新哈希。
2. `scripts/check_fonts.py` 使用字体 name、fvar、cmap 验证：Alibaba family 与 Regular、Noto family 与所需字重轴、项目所有字符。无法获取真正字体时，不声称已使用它。
3. 浏览器 await FontFaceSet.load，返回 FontFace 至少一个且状态 loaded，再开始首帧。只调用 document.fonts.check 或写了 CSS family 都不够。
4. 生成包含“制造业深度应用 / 高水平 / 工业领域 / 推广应用”的真实排版检查图，检查整行笔画与基线。以解码后的成片帧再看一次。

字体二进制不随本包分发，不提交到纯代码仓库。Alibaba 字体镜像地址、版本和校验值明确记录；镜像仓库的软件许可证不能自动视为字体本身的授权。使用者按原字体许可使用，不修改字形或转售字体。
