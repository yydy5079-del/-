# 来源与许可

- 设计需求：用户确认的工业 AI 工程简报板动画、局部结尾提示词，以及本次提供的文字清晰度截图。完整合成视频超过当前附件读取工具 32 MiB 上限，本次没有声称完整读取或逐镜拆解它；不把该私人附件打包再分发。
- 白板基础引擎：LemoLab / lemo-opuscar Engineering Briefing Board，https://github.com/lemomo-ai/lemo-opuscar/tree/main/styles/briefing-board/demo/kit ，MIT，许可保留于 templates/kit/LICENSE。本包增加稳定中文排版、Alibaba 辅助字分支、字体加载门槛、局部结尾及通用制作工具。没有复制原示例片的题材或音轨。
- Noto Sans SC：Google Fonts / Noto，SIL OFL 1.1，https://github.com/google/fonts/tree/main/ofl/notosanssc 。字体通过固定 URL 下载到外部缓存，非打包分发。
- Alibaba PuHuiTi Regular：阿里巴巴普惠体，字体 name table 验证 family 为 Alibaba PuHuiTi / 阿里巴巴普惠体，style 为 Regular，版本 1.10。原厂入口 https://www.alibabafonts.com/ 。固定版本镜像 https://github.com/chinayin/fonts-alibaba-puhuiti-regular/tree/88a08d2f53fadb50ce21d95fc5b1a265a5810688 。镜像仓库声明 Apache-2.0，但不据此声称字体本身为 Apache 授权；按原厂字体条款使用。本包只含下载位置、摘要和检测代码，不含字体二进制。
- 示例文字与程序 Foley 为本项目代码定义；语音始终由用户提供。新的照片、模型、商标、音乐需在各自成片的 CREDITS 中另记，不自动继承本项目授权。
- 本名称为用户指定的技能名称，不表示阿里巴巴、Noto、LemoLab 或模型厂商的官方产品或背书。
