# Opus5.5×Camera Motion Whiteboard Animation

将文案和原始口播音频制作成 1080p30 工程简报板科普动画。标准 Agent Skill：入口为 `SKILL.md`，展示名称为本页标题，调用标识为 `opus55-camera-motion-whiteboard-animation`。

已固定的偏好：一个事件一个场景、分句驱动内部动作、连续局部摄影机、禁止结尾全板回顾、二维矢量/2.5D、H.264/AAC、无字幕/交互 UI、原声同步、主要音效低约 8 dB、Noto Sans SC 主字、阿里巴巴普惠体 Regular 辅助字。默认自动完成分镜至成片；当次明确要求先确认时才暂停。

## 调用

上传 MP3，并输入：

> 调用 Opus5.5×Camera Motion Whiteboard Animation。文案如下：…… 按默认规格从分镜到成片直接完成。

## 安装

`python3 scripts/install.py --repo /absolute/path/to/repository` 安装到该仓库的 `.agents/skills/opus55-camera-motion-whiteboard-animation`。已存在的不同版本不覆盖，先报告差异。Codex 在新会话或重新扫描技能后识别；该安装不修改账号插件商店，也不会自动安装到其他电脑。

其他支持本地 Agent Skill 的工具：将本目录放进该工具规定的 skills 目录，让 agent 阅读 `SKILL.md`。具体安装入口以宿主工具为准，不承诺不同产品有相同的 UI。

## 文件

- `SKILL.md`：自动制作工作流与固定要求。
- `references/`：分镜、运镜、字体、音频、实现和交付规范。
- `templates/kit/board.js`：基于 MIT 白板引擎的修复版，辅助字不再随机旋转、缩放、漂移或描边。
- `scripts/`：安装、初始化、字体准备与检查、渲染、混音、编码和验收。
- `examples/`：最小字体/构图检查用例，非固定视频题材。

字体不包含在 ZIP 中；设置脚本下载固定版本到仓库外缓存并校验 SHA-256，避免将字体二进制放进纯代码仓库。大视频、原声、语音模型也不随包分发。

本包是 agent 的制作流程和工具箱。新的主题仍需 agent 根据原文与音频编排分镜、资产与时间轴；不会把任意文案自动替换进同一套场景。

素材来源和许可证见 `CREDITS.md`。请按各素材的实际许可使用和分发。
