"""Install a standard repository-local Codex skill without overwriting other versions."""
import argparse, filecmp, json, shutil
from pathlib import Path

src=Path(__file__).resolve().parents[1];slug='opus55-camera-motion-whiteboard-animation'
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);a=p.parse_args()
dest=a.repo.resolve()/'.agents/skills'/slug
if src==dest:
    print(json.dumps({'status':'installed','scope':'repository','path':str(dest),'existing':True}));raise SystemExit
if dest.exists():
    source={x.relative_to(src) for x in src.rglob('*') if x.is_file() and '__pycache__' not in x.parts}
    target={x.relative_to(dest) for x in dest.rglob('*') if x.is_file() and '__pycache__' not in x.parts}
    if source!=target or any(not filecmp.cmp(src/x,dest/x,shallow=False) for x in source):
        raise SystemExit('Different installed version exists; inspect and back it up before replacement: '+str(dest))
else:
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copytree(src,dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.DS_Store'))
assert (dest/'SKILL.md').is_file() and (dest/'agents/openai.yaml').is_file()
print(json.dumps({'status':'installed','scope':'repository','path':str(dest),'activation':'new conversation or skills/list forceReload'},ensure_ascii=False))
