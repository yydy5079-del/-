import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {pathToFileURL,fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const argv=process.argv.slice(2),arg=(k,d)=>{const i=argv.indexOf(k);return i<0?d:argv[i+1]};
const project=path.resolve(arg('--project','.')),runtime=JSON.parse(fs.readFileSync(arg('--runtime'),'utf8'));
const cfg=JSON.parse(fs.readFileSync(path.join(project,'project.json'),'utf8'));
const scene=JSON.parse(fs.readFileSync(path.join(project,cfg.scene||'scene.json'),'utf8'));
const out=path.resolve(cfg.output),boundary=path.resolve(cfg.source_repo||project);
if(out===boundary||out.startsWith(boundary+path.sep))throw Error('Output must be outside source repository');
if(Math.abs(scene.dur-cfg.frames/30)>.001)throw Error('Scene duration must match decoded narration frame count');
const {chromium}=await import(pathToFileURL(runtime.playwright_module).href);
const sample=scene.elements.map(e=>e.text||e.lines?.map(l=>l.text).join('')||'').join('');
const html=`<!doctype html><meta charset="utf-8"><style>@font-face{font-family:'Noto Sans SC';src:url('/fonts/NotoSansSC.ttf');font-weight:100 900}@font-face{font-family:'Alibaba PuHuiTi';src:url('/fonts/AlibabaPuHuiTi-Regular.ttf');font-weight:400}body{margin:0;font-synthesis:none}canvas{display:block}</style><canvas id="c" width="1920" height="1080"></canvas><script type="module">import{setScene,renderScene,loadFonts,sceneTexts,resCheck,camAt}from'/kit/board.js';try{const s=await(await fetch('/scene.json')).json();await loadFonts(${JSON.stringify(sample).replaceAll('<','\\u003c')});await setScene(s);window.draw=(t,review)=>{renderScene(document.getElementById('c'),t);return review?{cam:camAt(t),texts:sceneTexts(t),resolution:resCheck(t)}:null};window.READY=true}catch(e){window.FAIL=String(e);throw e}</script>`;
const server=http.createServer((req,res)=>{
  const u=decodeURIComponent(new URL(req.url,'http://localhost').pathname);let f;
  if(u==='/'){res.setHeader('Content-Type','text/html');res.end(html);return}
  if(u==='/scene.json'){res.setHeader('Content-Type','application/json');res.end(JSON.stringify(scene));return}
  if(u==='/kit/board.js')f=path.join(root,'templates/kit/board.js');
  else if(u.startsWith('/kit/objects/'))f=path.join(cfg.assets,path.basename(u));
  else if(u.startsWith('/fonts/'))f=path.join(runtime.fonts,path.basename(u));
  if(!f||!fs.existsSync(f)){res.writeHead(404);res.end('Not found');return}
  res.setHeader('Content-Type',f.endsWith('.js')?'text/javascript':f.endsWith('.json')?'application/json':f.endsWith('.png')?'image/png':'application/octet-stream');fs.createReadStream(f).pipe(res);
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const stillValue=arg('--stills',null),times=stillValue?stillValue.split(',').map(Number):Array.from({length:cfg.frames},(_,i)=>i/30);
const dir=path.join(out,stillValue?'review':'frames');fs.mkdirSync(dir,{recursive:true});
const errors=[],samples=[];let done=0;const start=Date.now();let browser;
try{
 browser=await chromium.launch({executablePath:runtime.chromium,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const workers=stillValue?1:Math.max(1,Math.min(4,Number(arg('--workers',2))));
 await Promise.all(Array.from({length:workers},async(_,worker)=>{
  const page=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});page.on('pageerror',e=>errors.push(String(e)));
  await page.goto(`http://127.0.0.1:${server.address().port}`);await page.waitForFunction(()=>window.READY||window.FAIL,null,{timeout:120000});
  const fail=await page.evaluate(()=>window.FAIL);if(fail)throw Error(fail);
  for(let i=worker;i<times.length;i+=workers){
   const t=times[i];const result=await page.evaluate(({t,review})=>({report:draw(t,review),jpeg:document.getElementById('c').toDataURL('image/jpeg',.96).split(',')[1]}),{t,review:!!stillValue||i%30===0});
   if(errors.length)throw Error(errors.join('\n'));if(result.report)samples.push({t,...result.report});
   fs.writeFileSync(path.join(dir,stillValue?`still-${t.toFixed(3)}.jpg`:`${String(i).padStart(6,'0')}.jpg`),Buffer.from(result.jpeg,'base64'));
   if(++done%90===0||done===times.length)console.log(`${done}/${times.length} frames, ${((Date.now()-start)/1000).toFixed(1)}s`);
  }
  await page.close();
 }));
 fs.writeFileSync(path.join(out,stillValue?'still-report.json':'render-report.json'),JSON.stringify({frames:done,seconds:(Date.now()-start)/1000,errors,samples},null,2));
}finally{if(browser)await browser.close();await new Promise(r=>server.close(r));}
