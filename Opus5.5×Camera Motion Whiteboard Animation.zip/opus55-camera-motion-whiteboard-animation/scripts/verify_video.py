import argparse,hashlib,json,re,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a=p.parse_args();cfg=json.loads((a.project/'project.json').read_text());out=Path(cfg['output']);video=out/'film.mp4'
j=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(video)]));v=next(x for x in j['streams'] if x['codec_type']=='video');au=next(x for x in j['streams'] if x['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],v['codec_name'],v['pix_fmt'],int(v['nb_frames']))==(1920,1080,'30/1','h264','yuv420p',cfg['frames'])
assert au['codec_name']=='aac' and int(au['sample_rate'])==48000
assert not any(x['codec_type']=='subtitle' for x in j['streams'])
assert abs(float(j['format']['duration'])-cfg['frames']/30)<.05
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(video),'-vf','blackdetect=d=0.07:pix_th=0.03:pic_th=0.99','-af','loudnorm=I=-14:TP=-1.5:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
assert 'black_start:' not in r.stderr,'Unexpected black interval'
ld=json.loads(re.findall(r'\{\s*"input_i".*?\}',r.stderr,re.S)[-1]);assert -15<float(ld['input_i'])<-13;assert float(ld['input_tp'])<=-1
sound=json.loads((out/'sound-report.json').read_text());delta=sound['sfx_below_voice_db']
assert delta is None or 7<=delta<=10
report={'resolution':'1920x1080','fps':30,'frames':cfg['frames'],'duration':float(j['format']['duration']),'codec':'H.264 / AAC','decode':'passed','black_frames':False,'subtitles':False,'loudness_lufs':float(ld['input_i']),'true_peak_dbtp':float(ld['input_tp']),'sfx_below_voice_db':delta,'sha256':hashlib.file_digest(video.open('rb'),'sha256').hexdigest(),'visual_review':'separate check required'}
(out/'quality-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
