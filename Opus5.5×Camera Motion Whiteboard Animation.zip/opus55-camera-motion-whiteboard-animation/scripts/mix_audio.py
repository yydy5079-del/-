"""Create deterministic board Foley and measure effect/voice separation."""
import argparse,json,subprocess,wave
from pathlib import Path
import numpy as np
from scipy.signal import butter,sosfilt
from scipy.ndimage import uniform_filter1d
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a=p.parse_args();cfg=json.loads((a.project/'project.json').read_text());out=Path(cfg['output']);out.mkdir(parents=True,exist_ok=True)
sr=48000;n=round(cfg['frames']/30*sr);rng=np.random.default_rng(41843)
raw=subprocess.check_output(['ffmpeg','-v','error','-i',cfg['audio'],'-f','f32le','-ar',str(sr),'-ac','1','-']);v=np.frombuffer(raw,np.float32).astype(float);v=np.pad(v,(0,max(0,n-len(v))))[:n];fx=np.zeros((n,2))
events=json.loads((a.project/cfg.get('cues','cues.json')).read_text())['events']
def rms(x):return float(np.sqrt(np.mean(x*x)+1e-15))
for e in events:
    t0=float(e['time']);d=float(e.get('duration',.25));assert 0<=t0<cfg['frames']/30 and d>0
    k=round(d*sr);t=np.arange(k)/sr;noise=sosfilt(butter(3,[300,1800],btype='bandpass',fs=sr,output='sos'),rng.standard_normal(k));kind=e['kind']
    if kind=='paper':s=(noise*.65+.15*np.sin(2*np.pi*90*t))*np.minimum(1,t/.012)*np.exp(-t/.07)
    elif kind=='magnet':s=(np.sin(2*np.pi*430*t)+.2*np.sin(2*np.pi*1050*t))*np.minimum(1,t/.002)*np.exp(-t/.026)
    elif kind=='pen':s=noise*np.sin(np.pi*t/d)**.8
    elif kind=='mechanical':s=(np.sin(2*np.pi*82*t)+noise*.08)*np.sin(np.pi*t/d)**2
    else:raise ValueError('Unknown Foley kind: '+kind)
    i=round(t0*sr);j=min(n,i+k);ref=v[max(0,i-3600):min(n,j+3600)];s*=rms(ref)/max(rms(s),1e-9)/10**(.4)
    pan=np.clip(e.get('pan',0),-1,1);st=np.stack([s*np.cos((pan+1)*np.pi/4),s*np.sin((pan+1)*np.pi/4)],axis=1)*np.sqrt(2);fx[i:j]+=st[:j-i]
ve=np.sqrt(uniform_filter1d(v*v,size=7200)+1e-12);fe=np.sqrt(uniform_filter1d(np.mean(fx*fx,axis=1),size=7200)+1e-12)
active=(ve>.015)&(fe>.003);ratio=None
if events:
    if np.count_nonzero(active)<480:raise SystemExit('No adequate simultaneous voice/effect window; revise cue timing before claiming −8 dB')
    fx*=rms(v[active])/max(rms(fx[active]),1e-9)/10**(.4)
    ratio=20*np.log10(rms(v[active])/rms(fx[active]))
vs=np.repeat(v[:,None],2,axis=1);mix=vs+fx;gain=min(1,.84/max(np.max(np.abs(mix)),1e-9))
def save(name,x):
    with wave.open(str(out/name),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((np.clip(x*gain,-1,1)*32767).astype('<i2').tobytes())
save('voice-stem.wav',vs);save('sfx-stem.wav',fx);save('mix-premaster.wav',mix)
report={'events':len(events),'sample_rate':sr,'duration':n/sr,'sfx_below_voice_db':ratio,'measurement':'RMS over matching 150 ms active voice/effect windows, before common mastering','peak_dbfs':float(20*np.log10(max(np.max(np.abs(mix*gain)),1e-12)))}
(out/'sound-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
