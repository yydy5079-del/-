"""Short isolated typography/encoding check. Not a template for every subject."""
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a=p.parse_args();cfg=json.loads((a.project/'project.json').read_text());d=cfg['frames']/30
if d<2:raise SystemExit('Font-check audio must be at least two seconds')
E=[{'type':'tag','id':'title','text':'中文排版检查','xy':[540,280],'size':95,'z':16}]
for i,text in enumerate(['制造业深度应用','高水平','工业领域','推广应用']):
    E.append({'id':'aux'+str(i),'type':'ink','kind':'write','text':text,'font':'aux','role':'aux','weight':400,'xy':[650,490+i*170],'size':48,'t':0,'d':.15,'color':'#454C55','reading':[.3,d]})
s={'dur':d,'board':{'w':3200,'h':2200,'texScale':.23,'ghosts':12,'seed':67},'hand':0,'sheen':.02,'cam':{'x':1250,'y':730,'z':.82,'moves':[]},'elements':E,'subs':[],'review':{'endingEvent':'局部辅助文字可读性检查','final_frame_region':[0,0,2500,1500]}}
(a.project/'scene.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
(a.project/'cues.json').write_text(json.dumps({'events':[{'time':.42,'kind':'paper','duration':.24},{'time':1.2,'kind':'pen','duration':.28}]}))
