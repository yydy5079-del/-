"""Meaningful static gates; visual/composition review remains required."""
import argparse,json,math
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a=p.parse_args()
cfg=json.loads((a.project/'project.json').read_text());s=json.loads((a.project/cfg.get('scene','scene.json')).read_text());errors=[]
def check(ok,msg):
    if not ok:errors.append(msg)
check((cfg['width'],cfg['height'],cfg['fps'])==(1920,1080,30),'1080p30 required')
check(cfg['frames']==math.ceil(cfg['duration']*30),'Frame count must follow decoded audio duration')
check(abs(s['dur']-cfg['frames']/30)<.001,'Scene duration differs from frame count')
check(not s.get('subs'),'Subtitle layer must be empty')
check(bool(s.get('review',{}).get('endingEvent')),'Document the independent final event in review.endingEvent')
rect=s.get('review',{}).get('final_frame_region')
check(rect and len(rect)==4,'Define final_frame_region [left,top,right,bottom] for the local ending')
c=s['cam'];z=c['z'];minz=z;cx=c['x'];cy=c['y'];roll=c.get('roll',0)
for m in c.get('moves',[]):
    check(m['d']>0,'Camera move duration must be positive');check(m.get('a',2)>=2 and m.get('b',2)>=2,'Camera ease must have smooth endpoint derivatives')
    z*=math.exp(m.get('dl',0));minz=min(minz,z);cx+=m.get('dx',0);cy+=m.get('dy',0);roll+=m.get('dr',0)
if rect and len(rect)==4:
    theta=math.radians(roll);rx=(960*abs(math.cos(theta))+540*abs(math.sin(theta)))/z;ry=(540*abs(math.cos(theta))+960*abs(math.sin(theta)))/z
    check(cx-rx>=rect[0] and cy-ry>=rect[1] and cx+rx<=rect[2] and cy+ry<=rect[3],'Final camera shows content outside the allowed local event region')
aux=0
for e in s['elements']:
    if e.get('role')=='aux' or e.get('font')=='aux':
        aux+=1;check(e.get('font')=='aux' and e.get('weight',400)==400,'Auxiliary text requires Alibaba font:aux and weight:400')
        check(not e.get('handLetter') and not e.get('rot') and not e.get('track'),'Auxiliary text cannot use hand-lettering, rotation or tracking distortion')
        # Conservative minimum. Actual per-reading-window screen bounds must also be reviewed.
        check(e.get('size',0)*minz>=30,'Auxiliary text too small at farthest camera: '+e.get('text',''))
        r=e.get('reading');check(r and r[1]-r[0]>=1.2,'Auxiliary text needs a documented clear reading window: '+e.get('text',''))
    for l in e.get('lines',[]):
        if l.get('role')=='aux' or l.get('font')=='aux':
            check(l.get('font')=='aux' and l.get('weight',400)==400,'Auxiliary card line font/weight mismatch')
            check(l.get('size',0)*minz>=30,'Auxiliary card line too small')
report={'passed':not errors,'auxiliary_elements':aux,'errors':errors,'visual_review_required':True}
print(json.dumps(report,ensure_ascii=False,indent=2))
if errors:raise SystemExit(1)
